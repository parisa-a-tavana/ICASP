#include<stdio.h>
main() {
	float n1, money1;
	int numN, numMoney, n, money;
	int count10 = 0;
	int count20 = 0;
	int count40 = 0;
	int invalid = 0;
	int impossible = 0;/*if we can't give a costumer their money we add 1 to this variable */
	int i = 1;
	numN = scanf("%f", &n1);
	n = n1;
	if ((numN == 0) || (n < n1)||(n<=0))/*we check if the input is valid*/
		printf("invalid input");
	else 
	{
		while ((invalid == 0) && (i <= n ))/*if we got all the n inputs we should stop getting input and if we get invalid input we
										   must stop immidiately*/
		{
			numMoney = scanf("%f", &money1);
			money = money1;
			if ((money < money1) || (numMoney == 0))
			{
				printf("invalid input");/*first we make sure that the input is integer */
				invalid++;
			}
			else
			{
				switch (money)
				{
				case 10:
					count10++;/*if we get 10 we count it*/
					break;
				case 20:
					count20++;/*if we get 20 we have to give 10 */
					count10--;
					if (count10 < 0) /*if we can't give the costumer 10, it's becous count10<=0 and when we do count10--
									 count10 becomes negative and the output must be NO but we can't break out of the rule 
									 so we add one to the "impossible" variable  */
						impossible++;
					break;
				case 40:
					count40++; /*when we get 40,we can either give one20 and one10 or give three10,if both ways are possible,we must choose 
							   the first way becous we spend 10 when we get 20 too*/
					count20--;
					count10--;
					if ((count20 < 0)||(count10<0) )/*if we don't have enough 20,count20<=0 and whe we do count20--,it becomes negative so we must check
									if we can give three 10 we have already  done count10-- so we do count10-=2 and becouse we don't give
									20, we do count20++.the problem may be becouse we don't have enough 10 too */
					{
						count20++;
						count10 -= 2;
					}
					if (count10 < 0)/*if we don't have at least three 10,count10 becomes negative.the other possibility is that we 
									had no 10 and in line 43 when we did count-- it became negative. and then we also did count10-=2 so 
									count10 is still negative andwe can't give the costumer their money */
						impossible++;/*we add one to the "impossible variable to show we can't give the costumer their money*/
					break;
				default:
					printf("invalid input");/*if input is an iteger other than 10,20 or 40 it's invalid and we must break out of the loop*/
					invalid++;/*so we add 1 to the "invalid" variable*/
						}

			}
			i++;

		}
		if ((invalid == 0) && (impossible == 0))/*when the loop is done,if an input is unvalid we must stop the only output must be "invalid input" 
												so for the "YES/NO" output we check if all the input are valid.
												the variable "impossible is either 0 or greater than 0 ,the first time that we add to the 
												"impossible" the out put must be No and the costumers after that don't matter whatever 
												happens to the "impossible" we are sure that it remains positive and "NO" will be printed.
												but if we can pay every costumer,  "impossible" remains 0 and we print "YES"*/ 		
			printf("YES");
		else if (invalid == 0)
			printf("NO");

	}





}