#include<stdio.h>
main() {
	float h, b, w; /*variable h is for max height of the ball in each round,w is height of the window and b is the coefficient */
	int valid;
	int count = 0;
	valid = scanf("%f%f%f", &h, &b, &w);
	if (valid !=3) /*we check if  inputs are valid*/
		printf("invalid input");
	else
	{
		if ((h > 0) && (b > 0) && (b < 1) && (w < h)&&(w>0)) /*we check if inputs have all the conditions */
		{
			while (h > w) 
			{
				count += 2; /*for each h we count it twice becous except the first time the ball goes up and down*/
				h *= b; /*evey time the  ball hits the goround h changes and becomes h.b */
			}
			count--; /*the first time the ball just goes down but we counted it twice*/
			printf("%d", count);
		}
		else /*if at least one of the conditions is false we print-1*/
			printf("-1");
	}
	return 0;
}