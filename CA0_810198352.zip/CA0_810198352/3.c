#include<stdio.h>
main() {
	int n, a, b, c, holder, i; /*a,b,c, are the first three members of the sequence and n is the number of members*/
	float n1, a1, b1, c1;
	int numN,valid;
	numN = scanf("%f", &n1);
	n = n1;
	if (numN == 0 || (n < n1)||(n<0)) /*we check if the input is valid*/
		printf("invalid input");
	else
	{
		valid = scanf("%f%f%f", &a1, &b1, &c1);
		a = a1;
		b = b1;
		c = c1;
		if (n!=0) /*if n=0 the input is valid but we don;t have output*/
		{
			if ((valid != 3) || (a < a1) || (b < b1) || (c < c1) || (c<0) || (b<0) || (a<0))/*we check if a,b,c are valid*/
				printf("invalid input");
			else
				switch (n)
				{
				case 1:
					printf("%d", a);
					break;
				case 2:
					printf("%d,", a);
					printf("%d", b);
					break;
				case 3:
					printf("%d,", a);
					printf("%d,", b);
					printf("%d", c);
					break;
				default:
					printf("%d,", a);
					printf("%d,", b);
					printf("%d", c);
					for (i=4;i<=n;i++)
					{
						holder = a + b + c;    /*cosider the sequence X=x1,x2,x3,x4,...
							              in this loop 4<=i<=n:c=x[i-1] ,b=x[i-2] ,a=x[i-3] we set holder=a[i]=a+b+c.then every time we shift a,b,c:
										 a=x[i-2](assign b's value to a) b=x[i-1](assign c's value to b) c=a[i](assign holder's value to c)*/
						printf(",%d", holder);
						a = b;
						b = c;
						c = holder;
					}




				}
		}

	}
	return 0;
}