#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"valid.h"
#include"getp.h"
#include"getr.h"
#include"printt.h"
#include"put.h"
#include"rotate.h"
#include"done.h"
#include"win.h"
#include"gets.h"
int main()
{
	char a[6][6];
	
	int turnnum = 0;
	int turn, position, region, whitewin, blackwin;
	char sign, colour;
	int i, j;
	int finish = 0;
	for (i = 0;i <= 5;i++)
		for (j = 0;j <= 5;j++)
			a[i][j] = '.';
	fprintt(a);      /*prints the game board*/
	while (finish == 0)
	{
		turnnum++;                                /*shomareye nobat bazi ra mishomarad */
		turn = turnnum % 2;                       /*turn=1->black player   turn=0->white player*/
		position = fgetposition(a, turn);        /*jaye mohre ra az user migirad*/
		fputcolour(position, a, turn);          /*khaneye moadel ra dar arrey a 'w' ya 'b' mikonad*/
		system("cls");
		fprintt(a);                           /*safhe update mishavad*/
		region = fgetregion();              /*nahiye mokhtasati gerefte mishavad*/
		sign = fgetsign();                 /*alamat rotate gerefte mishavad*/
		frotate(sign, region, a);           /*arrey a motenasb taghyir mikonad ta betavanad becharkhad */
		system("cls");
		fprintt(a);                         /*safhe update mishavad*/
		colour = 'b';
		blackwin = fcheckwinner(a, colour);      /* check if black player has won*/
		colour = 'w';
		whitewin = fcheckwinner(a, colour);       /*check if white player has won*/
		finish = fcheckdone(a);                    /*check if all spaces are filled*/
		if (blackwin > 0 && whitewin > 0)/*if both players have won*/
		{
			finish++;       /*so we can come out of the game loop*/
			printf("BOTH WON\n");

		}
		else if (blackwin > 0)/*if only black has won*/
		{
			finish++;     /*so we can come out of the game loop*/
			printf("BLACK PLAYER HAS WON\n");
		}
		else if (whitewin > 0)/*if only white has won*/
		{
			finish++;   /*so we can come out of the game loop*/
			printf("WHITE PLAYER HAS WON\n");
		}
		else if (finish > 0)
		{
			
			printf("NO ONE WON\n ");
		}

	}
}
