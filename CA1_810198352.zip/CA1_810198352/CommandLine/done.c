#include<stdio.h>
int fcheckdone(char a[6][6])/*this function checks if all the spaces are filled  */
{
	int done = 0;
	for (int i = 0;i <= 5;i++)
		for (int j = 0;j <= 5;j++)
			if (a[i][j] != '.')
				done++;
	if (done == 36)
		return 1;
	else
		return 0;
}