int fcheckdone(char a[6][6]);
/*function fchackdone checks if all the spaces are filled*/







