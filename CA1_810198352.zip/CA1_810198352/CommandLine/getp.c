#include<stdio.h>
#include<string.h>
#include"valid.h"

int fgetposition(char a[6][6], int turn)/*function fgetposition check mikonad ke voroodi ye position sahih tekrari nabashad*/
{
	int notfinished, input;
	do
	{
		notfinished = 0;
		if (turn == 1)
			input = fvalid(1);/* we get input that is int and between 11 _66 */
		else
			input = fvalid(2);/*fvalid(1)->asks  black user and fvalid(2)->asks  white user*/
		int column = input % 10;/*yekan->column*/
		int row = (input - column) / 10;/*dahgan->row*/
		if (a[row - 1][column - 1] == 'w' || a[row - 1][column - 1] == 'b')/*we check if the input is repeated or not*/
		{
			printf("repeated\n");/*if repeated notfinished++ ta dar loop beamnad*/
			notfinished++;
		}

	} while (notfinished > 0);
	return input;
}