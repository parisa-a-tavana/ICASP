int fgetposition(char a[6][6], int turn);
/*function fgetposition check mikonad ke voroodi positione sahih tekrari nabashad*/