#include<stdio.h>
#include<string.h>
int fgetregion()/*it's a function that gets the region input and chacks if it's valid*/
{
	char input[64];
	int region = 0;
	while (region == 0)
	{
		printf("Enter Region Number: \n");
		fgets(input, 63, stdin);
		if (strlen(input) > 2 || strlen(input) < 1)/*voroodi ra gerefte va dar array input mirizim 
												   agar karbar tedad ziadi char vared karde bashad error midahad
												   va be avale loop miravad*/
		{
			printf("invalid input\n");
			continue;
		}
		if (sscanf(input, "%d", &region) != 1)/*hal voroodi gerefte shode ra dar variable region mirizim 
											 va check mikonim ke int bashad agar nabood region=0 va continiue
											 ta dar loop bemanad*/
		{
			region = 0;
			printf("invalid input\n");
			continue;
		}
		if (region < 1 || region>4)/*hal region ra check mikonim ke dar bazeye dorost bashad agar ghalat bood region=0 va continiue
							 ta az loop kharej nashavad*/
		{
			region= 0;
			printf("invalid input\n");
			continue;
		}



	}
	return region;/*we return region that is  1<=int<=4  */

}