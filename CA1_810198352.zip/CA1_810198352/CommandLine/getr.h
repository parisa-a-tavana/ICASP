int fgetregion();
/*it's a function that gets the region input and chacks if it's valid*/