#include<stdio.h>
#include<string.h>
char fgetsign()/*it's a function that get's sign from user and checks if it's valid*/
{
	char input[64];
	int finish = 0;
	char sign;
	while (finish == 0)
	{
		printf("enter sign\n");
		fgets(input, 63, stdin);
		if (strlen(input) > 2 || strlen(input) < 1)/*voroodi ra gerefte va dar array input mirizim 
												   agar karbar tedad ziadi char vared karde bashad error midahad*/
		{
			printf("invalid input\n");
			continue;
		}
		if (sscanf(input, "%c", &sign) != 1)/*hal voroodi gerefte shode ra dar variable sign mirizim 
											 va check mikonim ke char bashad agar nabood  continiue
											 ta dar loop bemanad*/
		{
			
			printf("invalid input\n");
			continue;
		}
		if (sign == '+' || sign == '-')/*hal check mikonim ke char - ya + bashad agar bood,finsh++ ta az loop kharej shavad*/
		{
			finish++;
		}
		else/*agar ham - + nabood error midahad va finish=0 ta dar loop bemanad*/
		{
			printf("invalid input\n ");
			
		}


	}
	return sign;

}