char fgetsign();
/*it's a function that get's sign from user and checks if it's valid*/