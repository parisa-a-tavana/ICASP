#include<stdio.h>
void fprintt(char a[6][6])/*it's a function that prints the game board*/
{
	printf("\t");
	int i, j;
	for (i = 1;i <= 3;i++)/* 3 adad aval balaye jadval ra mikeshad*/
		printf("%d\t", i);
	printf("|\t");
	for (i = 4;i <= 6;i++)/* 3 adad dovom balaye jadval ra mikeshad*/
		printf("%d\t", i);
	printf("\n");
	for (i = 0;i <= 2;i++)/*khane haye 3 satre aval ra print mikonad*/
	{
		printf("%d\t", i + 1);
		for (j = 0;j <= 2;j++)
			printf("%c\t", a[i][j]);
		printf("|\t");
		for (j = 3;j <= 5;j++)
			printf("%c\t", a[i][j]);
		printf("\n");
	}
	printf("--\t--\t--\t--\t\t--\t--\t--");
	printf("\n");
	for (i = 3;i <= 5;i++)/*khane haye 3 satre dovom ra print mikonad*/
	{
		printf("%d\t", i + 1);
		for (j = 0;j <= 2;j++)
			printf("%c\t", a[i][j]);
		printf("|\t");
		for (j = 3;j <= 5;j++)
			printf("%c\t", a[i][j]);
		printf("\n");
	}
}

