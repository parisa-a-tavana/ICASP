void fprintt(char a[6][6]);
/*it's a function that prints the game board*/
