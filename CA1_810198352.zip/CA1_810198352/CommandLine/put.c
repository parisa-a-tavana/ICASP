#include<stdio.h>
void fputcolour(int position, char a[6][6], int turn)/*function fputcolour ba tavjoh be voroodi 2 raghami karbar
													 khane motenazer ra 'w' ya 'b' gharar midihad*/
{
	int column = position % 10;/*yekan->column*/
	int row = (position - column) / 10;/*dahgan->row*/
	if (turn == 1)
		a[row - 1][column - 1] = 'b';
	else
		a[row - 1][column - 1] = 'w';
}