void fputcolour(int position, char a[6][6], int turn);
/*function fputcolour ba tavjoh be voroodi 2 raghami karbar
khane motenazer ra 'w' ya 'b' gharar midihad*/