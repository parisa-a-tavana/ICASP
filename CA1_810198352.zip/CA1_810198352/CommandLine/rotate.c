#include<stdio.h>
void frotate(char sign, int region, char a[6][6])/*function frotate meghdar arrey a ra tori taghir midahad
												 ke nahiye morede nazar charkhande shavad*/ 
{
	int i, j;/*int i ->row index  int j->column index*/
	char b[6][6];
	for (i = 0;i <= 5;i++)
		for (j = 0;j <= 5;j++)
			b[i][j] = a[i][j];
	switch (region)
	{
	case 2:
		i = 0;/*avalin khane nahiye 2 mokhtasati a[0][0]*/
		j = 0;
		break;
	case 1:/*avalin khane nahiye 1 mokhtasati a[0][3]*/
		i = 0;
		j = 3;
		break;
	case 3:/*avalin khane nahiye 3 mokhtasati a[3][0]*/
		i = 3;
		j = 0;
		break;
	default:/*avalin khane nahiye 4 mokhtasati a[3][3]*/
		i = 3;
		j = 3;
	}
	if (sign == '-')/*if input is - rotate anti-clockwise*/
	{
		a[i][j] = b[i][j + 2];
		a[i][j + 1] = b[i + 1][j + 2];
		a[i][j + 2] = b[i + 2][j + 2];
		a[i + 1][j + 2] = b[i + 2][j + 1];
		a[i + 2][j + 2] = b[i + 2][j];
		a[i + 2][j + 1] = b[i + 1][j];
		a[i + 2][j] = b[i][j];
		a[i + 1][j] = b[i][j + 1];

	}
	if (sign == '+')/*if sign + rotate clockwise*/
	{
		a[i][j + 2] = b[i][j];
		a[i + 1][j + 2] = b[i][j + 1];
		a[i + 2][j + 2] = b[i][j + 2];
		a[i + 2][j + 1] = b[i + 1][j + 2];
		a[i + 2][j] = b[i + 2][j + 2];
		a[i + 1][j] = b[i + 2][j + 1];
		a[i][j] = b[i + 2][j];
		a[i][j + 1] = b[i + 1][j];

	}

}
