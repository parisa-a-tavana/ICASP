void frotate(char sign, int region, char a[6][6]);
/*function frotate meghdar arrey a ra tori taghir midahad ke nahiye morede nazar charkhande shavad*/