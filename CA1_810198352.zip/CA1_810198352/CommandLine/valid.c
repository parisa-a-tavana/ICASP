#include<stdio.h>
#include<string.h>

int fvalid(int turn)/*function fvalid ba komake variable turn payam monaseb baraye user print mikonad
					( agar voroodi 11<int<66 nabashad error midahad) va voroodi ra return mikonad*/
{
	int region;
	char input[64];
	region = 0;
	while (region == 0)
	{
		if (turn == 1)
			printf("Black Player's Turn:\n");
		else
			printf("White Player's Turn:\n");
		fgets(input, 63, stdin);
		if (strlen(input) > 3 || strlen(input) < 2)/*voroodi ra gerefte va dar array input mirizim 
												   agar karbar tedad ziadi char vared karde bashad error midahad
												   va continiue ta dar loop bemanad ( be check baghiye shart ha niaz nist)*/
		{
			printf("invalid input\n");
			continue;
		}
		if (sscanf_s(input, "%d", &region) != 1)/*hal voroodi gerefte shode ra dar variable region mirizim 
											 va check mikonim ke int bashad agar nabood region=0 &continiue ta dar loop 
											 bemanad (va be check baghiye niaz nist)*/
		{
			region = 0;
			printf("invalid input\n");
			continue;
		}
		if (region < 11 || region>66)/*hal region ra check mikonim ke dar bazeye dorost(11,66) bashad agar nabood region=0 va continiue 
							   ta dar loop bemanad*/
		{
			region = 0;
			printf("invalid input\n");
			continue;
		}
	}

	return region;
}