int fvalid(int turn);
/*function fvalid ba turn payam monaseb baraye user print mikonad
(agar voroodi 11<int<66 nabashad error midahad) va voroodi ra return mikonad*/
