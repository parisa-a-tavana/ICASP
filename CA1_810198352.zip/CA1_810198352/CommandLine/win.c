#include<stdio.h>
int fcheckwinner(char a[6][6], char colour)/*this function checks if a player has won*/
{
	int finish = 0;/*agar int finish >0 shavad yani bazi tamam mishavad chon bazikoni ke darad check mishavad borde*/
	int i, j;/*int i->row index    int j->column index*/
	char x;
	if (colour == 'b')
		x = 'b';
	else if (colour == 'w')
		x = 'w';
	for (j = 0;j <= 4;j++)
		for (i = 0;i <= 2;i++)
			if ((a[i][j] == x && a[i][j + 1] == x && a[i + 1][j] == x && a[i + 2][j] == x && a[i + 3][j] == x))
				finish++;
	/*..
	  .
	  .ra dar tamam jadval check mikonad*/
	for (i = 0;i <= 4;i++)
		for (j = 5;j >= 3;j--)
			if ((a[i][j] && a[i + 1][j] == x && a[i][j - 1] == x && a[i][j - 2] == x && a[i][j - 3] == x))
				finish++;
	/*...
	    . ra dar tamam jadval check mikonad*/
	for (j = 5;j >= 1;j--)
		for (i = 5;i >= 3;i--)
			if ((a[i][j] == x && a[i][j - 1] == x && a[i - 1][j] == x && a[i - 2][j] == x && a[i - 3][j] == x))
				finish++;
	/* .
	   .
	  ..  ra dar tamam jadval check mikonad*/

	for (i = 5;i >= 1;i--)
		for (j = 0;j <= 2;j++)
			if ((a[i][j] == x && a[i - 1][j] == x && a[i][j + 1] == x && a[i][j + 2] == x && a[i][j + 3] == x))
				finish++;
      /*.
	    ... ra dar tamam jadval check mikonad*/
	for (j = 5;j >= 1;j--)
		for (i = 0;i <= 2;i++)
			if ((a[i][j] == x && a[i][j - 1] == x && a[i + 1][j] == x && a[i + 2][j] == x && a[i + 3][j] == x))
				finish++;
	/*..
	   .
	   . ra dar tamam jadval check mikonad*/
	for (i = 5;i >= 1;i--)
		for (j = 5;j >= 3;j--)
			if ((a[i][j] == x && a[i - 1][j] == x && a[i][j - 1] == x && a[i][j - 2] == x && a[i][j - 3] == x))
				finish++;
	/* .
	 ... ra dar tamam jadval check mikonad */
	for (j = 0;j <= 4;j++)
		for (i = 5;i >= 3;i--)
			if ((a[i][j] == x && a[i][j + 1] == x && a[i - 1][j] == x && a[i - 2][j] == x && a[i - 3][j] == x))
				finish++;
	/* .
	   .
	   .. ra dar tamam jadval check mikonad*/
	for (i = 0;i <= 4;i++)
		for (j = 0;j <= 2;j++)
			if ((a[i][j] == x && a[i + 1][j] == x && a[i][j + 1] == x && a[i][j + 2] == x && a[i][j + 3] == x))
				finish++;
	/*...
	  . ra dar tamam jadval check mikonad*/
	
	/*hal be soragh movarab ha miravim*/
	if ((a[2][0] == x && a[3][1] == x && a[4][2] == x && a[5][3] == x && (a[4][4] == x || a[1][1] == x)) ||/*yek ghotr ra migirad va tamam halat haye momken an ra chack mikonad*/
		(a[5][2] == x && a[4][3] == x && a[3][4] == x && a[2][5] == x && (a[1][4] == x || a[4][1] == x)) ||/*dar har khat kar bala ra anjam midihad va ghotr motefavet*/
		(a[0][2] == x && a[1][3] == x && a[2][4] == x && a[3][5] == x && (a[4][4] == x || a[1][1] == x)) ||
		(a[3][0] == x && a[2][1] == x && a[1][2] == x && a[0][3] == x && (a[1][4] == x || a[4][1] == x)) ||
		(a[5][4] == x && a[4][3] == x && a[3][2] == x && a[2][1] == x && (a[1][2] == x || a[3][0] == x || a[4][5] == x)) ||
		(a[4][3] == x && a[3][2] == x && a[2][1] == x && a[1][0] == x && (a[0][1] == x || a[5][2] == x || a[3][4] == x)) ||
		(a[5][1] == x && a[4][2] == x && a[3][3] == x && a[2][4] == x && (a[4][0] == x || a[1][3] == x || a[3][5] == x)) ||
		(a[4][2] == x && a[3][3] == x && a[2][4] == x && a[1][5] == x && (a[0][4] == x || a[3][1] == x || a[5][3] == x)) ||
		(a[4][0] == x && a[3][1] == x && a[2][2] == x && a[1][3] == x && (a[0][2] == x || a[2][4] == x || a[5][1] == x)) ||
		(a[3][1] == x && a[2][2] == x && a[1][3] == x && a[0][4] == x && (a[1][5] == x || a[2][0] == x || a[4][2] == x)) ||
		(a[4][5] == x && a[3][4] == x && a[2][3] == x && a[1][2] == x && (a[5][4] == x || a[0][3] == x || a[2][1] == x)) ||
		(a[3][4] == x && a[2][3] == x && a[1][2] == x && a[0][1] == x && (a[1][0] == x || a[4][3] == x || a[2][5] == x)) ||
		(a[5][0] == x && a[4][1] == x && a[3][2] == x && a[2][3] == x && (a[1][2] == x || a[3][4] == x)) ||
		(a[4][1] == x && a[3][2] == x && a[2][3] == x && a[1][4] == x && (a[0][3] == x || a[2][5] == x || a[3][0] == x || a[5][2] == x)) ||
		(a[0][5] == x && a[1][4] == x && a[2][3] == x && a[3][2] == x && (a[2][1] == x || a[4][3] == x)) ||
		(a[5][5] == x && a[4][4] == x && a[3][3] == x && a[2][2] == x && (a[1][3] == x || a[3][1] == x)) ||
		(a[4][4] == x && a[3][3] == x && a[2][2] == x && a[1][1] == x && (a[5][3] == x || a[3][5] == x || a[2][0] == x || a[0][2] == x)) ||
		(a[0][0] == x && a[1][1] == x && a[2][2] == x && a[3][3] == x && (a[4][2] == x || a[2][4] == x)))
		finish++;/*agar har yek az shart ha bargharar bashad yani movarab 'b' ya 'w' sakhte shose */
	return finish;/*agar har yek az sharayete bord bazikon x(b or w) bargharar bashad finish>0 
				  else ->finish=0*/
}
