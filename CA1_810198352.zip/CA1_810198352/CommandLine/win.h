int fcheckwinner(char a[6][6], char colour);
/*this function checks if a player has won*/