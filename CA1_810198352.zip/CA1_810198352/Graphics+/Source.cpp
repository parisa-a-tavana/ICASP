#include"graphics.h"
#include<stdio.h>
#include"priint.h"
#include"position.h"
#include"signmouse.h"
#include"regionmouse.h"
#include"rotate.h"
#include"wiiiin.h"
#include"done.h"



int main() {
	int wid = ALL_WINDOWS;
	initwindow(900, 900,"PENTAGOL");
	char a[6][6];
	for (int i = 0;i <= 5;i++)/*we initialize arrey a*/
		for (int j = 0;j <= 5;j++)
			a[i][j] = '.';
	int turnnum = 0;
	char sign,colour;
	int region,blackwin,whitewin,turn;
	
	int finish = 0;
	while (finish==0)
	{
		turnnum ++;       /*shomareye nobat ra mishomarad */
		turn = turnnum % 2;       /*turn=1->black player   turn=0->white player*/
		fprint(a, 50, 50);        /*game board ra ba tavajoh be khane haye w,b mikeshad*/
		fposition(a, turn);        /*ba gereftane voroodi monaseb khane monaseb ra w,b mikonim*/
		cleardevice();
		fprint(a, 50, 50);        /*safhe ra update mikonim*/
		region = fmouseregion();    /*ba gereftane voroodi monaseb nahiye charkhandan ra moshakhas mikonim*/
		cleardevice();
		fprint(a, 50, 50);  /*safhe ra update mikonim ta comment ha delete shavad az safhe*/
		sign = fmousesign();  /*ba gereftane voroodi monaseb jahate charkhesh ra moshakhas*/
		frotate(sign, region, a);       /*arrey a micharkhad*/
		cleardevice();
		fprint(a, 50, 50);            /*safhe update mishavad*/
		colour = 'b';
		blackwin = fcheckwinner(a, colour);  /* check if black player has won*/
		colour = 'w';
		whitewin = fcheckwinner(a, colour);    /*check if white player has won*/
		finish = fcheckdone(a);                /*check if all spaces are filled*/
		setcolor(15);
		if (whitewin > 0 && blackwin > 0)/*if both players have won*/
		{
			finish++;      /*so we can come out of the game loop*/
			outtextxy(650, 0, "BOTH WON");
			outtextxy(650, 100, "press any key to exit");
		}
		else if (whitewin > 0)/*if only white has won*/
		{
			finish++;
			outtextxy(650, 0, "WHITE PLAYER HAS WON");
			outtextxy(650, 100, "press any key to exit");
		}
		else if (blackwin > 0)/*if only black has won*/
		{
			finish++;
			outtextxy(650, 0, "BLACK PLAYER HAS WON");
			outtextxy(650, 100, "press any key to exit");
		}
		else if (finish > 0)
		{
			outtextxy(650, 50, "NO ONE WON");
			outtextxy(650, 100, "press any key to exit");
		}
	}
		
	getch();
	closegraph();

	
	
}

	