#include"graphics.h"
int fmouseregion()/*it's a function that gets mouse input for region*/
{
	int finish, x1mouse, y1mouse,region;
	finish= 0;
	while (finish == 0)
	{
		setcolor(15);
		outtextxy(650, 0, "double click on the region");
		if (ismouseclick(WM_LBUTTONDBLCLK))/*vaghti mouse double click shod*/
			if (ismouseclick(WM_LBUTTONDBLCLK))
		{
			x1mouse = mousex();/*mokhtasate mouse ra dar an lahze migirim*/
			y1mouse = mousey();
			if (x1mouse > 0 && x1mouse < 300 && y1mouse>0 && y1mouse < 300)/*agar dar mahdoode 2*/
			{
				region = 50;//region2

				finish++;
			}
			else if (x1mouse > 0 && x1mouse < 300 && y1mouse>300 && y1mouse < 600)/*agar dar mahdoode 3*/
			{
				region = 51;//region3 51->ascii code 3
				finish++;
			}
			else if (x1mouse > 300 && x1mouse < 600 && y1mouse>0 && y1mouse < 300)/*agar dar mahdoode 1*/
			{
				region = 49;//region1 49->ascii code 1
				finish++;
			}
			else if (x1mouse > 300 && x1mouse < 600 && y1mouse>300 && y1mouse < 600)/*agar dar mahdoode 4*/
			{
				region = 52;//region4 52->ascii code 4
				finish++;
			}
			else
			{
				setcolor(15);
				outtextxy(650, 50, "you clicked on a wrong place");
			}
		}
		clearmouseclick(WM_LBUTTONDBLCLK);
	}
	return region;
}