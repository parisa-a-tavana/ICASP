int fmouseregion();
/*it's a function that gets mouse input for region*/