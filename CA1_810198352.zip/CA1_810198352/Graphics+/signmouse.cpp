#include"graphics.h"
char fmousesign()/*it's a function that gets mouse input for sign*/
{
	int finish, x1mouse, y1mouse;
	char sign;
	finish = 0;
	while (finish == 0)
	{
		setcolor(15);
		outtextxy(650, 0, "double click on the sign");
		if (ismouseclick(WM_LBUTTONDBLCLK))/*vaghti mouse double click shod*/
		{
			x1mouse = mousex();/*mokhtasate mouse ra dar an lahze migirim*/
			y1mouse = mousey();
			if (x1mouse > 650 && x1mouse < 700 && y1mouse>275 && y1mouse < 325)/*agar dar mahdoode sign-*/
			{
				sign = '-';
				finish++;
			}
			else if (x1mouse > 700 && x1mouse < 750 && y1mouse>275 && y1mouse < 325)/*agar dar mahdoode sign+*/
			{
				sign = '+';
				finish++;
			}
			else
			outtextxy(650, 100, "you clicked on a wrong place");
		}
		clearmouseclick(WM_LBUTTONDBLCLK);
	}
	return sign;
}