char fmousesign();
/*it's a function that gets mouse input for sign*/