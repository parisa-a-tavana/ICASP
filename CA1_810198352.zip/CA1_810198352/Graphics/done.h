int fcheckdone(char a[6][6]);
/*this function checks if all the spaces are filled  */
