#include"graphics.h"
#include<stdio.h>
#include"priint.h"

void fposition(char a[6][6], int turn)/*this function gets input and fills the spaces*/
{
	int finish = 0;
	char input;
	int xpointer = 50;/* x pointer->x moraba neshangar dar safhe(pointer is automatiacally at (50,50) */
	int ypointer = 50;/* y pointer->y moraba neshangar dar safhe */
	int i, j;
	while (finish == 0)
	{
		setcolor(15);
		if (turn == 1)
			outtextxy(650, 0, "Black Player's Turn:");
		else
			outtextxy(650, 0, "Whte Player's Turn:");

		input = getch();
		if (input == 'w')/*if input=w agar pointer mitavanad 1 khane bala ravad va safhe update shavad*/
		{
			if (ypointer >= 150)
			{
				ypointer -= 100;
				clearviewport();
				fprint(a, xpointer, ypointer);
			}

		}
		else if (input == 's')/*if input=s agar pointer mitavanad 1 khane payin ravad*/
		{
			if (ypointer <= 450)
			{
				ypointer += 100;
				clearviewport();
				fprint(a, xpointer, ypointer);
			}
		}
		else if (input == 'a')/*if input=a  agar mitavanad 1 khane chap  ravad va safhe update shavad*/
		{
			if (xpointer >= 150)
			{
				xpointer -= 100;
				clearviewport();
				fprint(a, xpointer, ypointer);
			}
		}
		else if (input == 'd')/*if input=d agar mitavanad 1 khane rast ravad va safhe update shavad*/
		{
			if (xpointer <= 450)
			{
				xpointer += 100;
				clearviewport();
				fprint(a, xpointer, ypointer);
			}
		}
		else if (input == 'f')/*if input=f 1check konad khane por nabashad agar nabood por konad va safhe update shavad*/
		{
			j = (xpointer - 50) / 100;/*chon j index number column hast va be soorate ofoghi va xpointer x mokhtasat hast*/
			i = (ypointer - 50) / 100;/*chon i index number row hast va be soorate amoodi va ypointer y mokhtasat hast*/
			if (a[i][j] != 'b'&&a[i][j] != 'w')
			{
				if (turn == 1)
					a[i][j] = 'b';
				else
					a[i][j] = 'w';
				clearviewport(); /*pas az gereftan iput dorost safhe ra update mikonad va finish=1 ta az loop kharej shavad */
				fprint(a, xpointer, ypointer);
				finish = 1;
			}
			else
			{
				finish = 0;/*agar voroodi f vali khane tekrari*/
				outtextxy(650, 100, "   repeated. try again  ");
			}
		}
		else/*if input != wasdf*/
		{
			finish = 0;
			setcolor(15);
			outtextxy(650, 100, "invalid input.try again");
		}
	

	}
}