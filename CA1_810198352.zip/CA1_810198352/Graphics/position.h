void fposition(char a[6][6], int turn);
/*this function gets input and fills the spaces*/
