#include"graphics.h"
void fprint(char a[6][6], int xpointer, int ypointer)/*this function prints the game board*/
{
	int i, j,xj,yi;
	
	setfillstyle(1,COLOR(200,0,0));
	bar(0, 0, 600, 600);
	setcolor(15);
	line(300, 0, 300, 600);
	line(0, 300, 600, 300);
	for(i=0;i<=5;i++)/*khane ha ra ba tavajoh be inke por shode ya na mikeshad*/
		for (j = 0;j <= 5;j++)
		{
			yi = i * 100 + 50;/*chon yi mokhtasate mehvar y hast va i index row ->i ha be soorate amoodi posht ham gharar migirand*/
			xj = j * 100 + 50;/*chon xj moktasate mehvare x hast va j index column->j ha  be soorate ofoghi posht ham gharar migirand*/
			if (a[i][j] == 'w')/*draw white circle*/
			{
				setfillstyle(1, 15);
				fillellipse(xj, yi, 20, 20);
			}
			else if (a[i][j] == 'b')/*draw black circle*/
			{
				setfillstyle(1, 0);
				fillellipse(xj, yi, 20, 20);

			}
			else/*draw emty circle*/
			{
				circle(xj, yi, 20);
			}

		}

	setcolor(COLOR(0, 0, 200));/*moraba neshangar(pointer) ra dar mokhtasati ke be onvan voroody dade shode mikeshad*/
	rectangle(xpointer-5, ypointer, xpointer + 5, ypointer + 5);
}