void fprint(char a[6][6], int xpointer, int ypointer);
/*this function prints the game board*/