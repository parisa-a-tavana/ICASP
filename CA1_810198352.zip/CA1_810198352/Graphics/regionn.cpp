#include"graphics.h"
int fgetregion()/*this function gets region input and checks if its valid*/
{
	int finish = 0;
	int region;
	while (finish == 0)
	{
		setcolor(15);
		outtextxy(650, 0, "enter region");
		region = getch();
		if (region == 49 || region == 50 || region == 51 || region == 52)/*we get input as char so we should write the ascii
																		 code of 1,2,3,4*/
			finish++;
		else
			outtextxy(650, 50, "invalid input");
	}
	return region;
}