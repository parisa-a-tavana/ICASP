int fgetregion();
/*this function gets region input and checks if its valid*/