#include<stdio.h>
void frotate(char sign, int region, char a[6][6])
{
	int i, j;
	char b[6][6];
	for (i = 0;i <= 5;i++)
		for (j = 0;j <= 5;j++)
			b[i][j] = a[i][j];
	switch (region)
	{
	case 50://region 2 20->ascii code 2
		i = 0;//first element of region 2 a[0][0]
		j = 0;
		break;
	case 49://region 1 49->ascii code 1
		i = 0;//first element of region1 a[0][3]
		j = 3;
		break;
	case 51://region 3 51->ascii code 3
		i = 3;//first element region 3 a[3][0]
		j = 0;
		break;
	default://case 4
		i = 3;//first element region 4 a[3][3]
		j = 3;
	}
	if (sign == '-')/*if sign - ->rotate anti-clockwise*/
	{
		a[i][j] = b[i][j + 2];
		a[i][j + 1] = b[i + 1][j + 2];
		a[i][j + 2] = b[i + 2][j + 2];
		a[i + 1][j + 2] = b[i + 2][j + 1];
		a[i + 2][j + 2] = b[i + 2][j];
		a[i + 2][j + 1] = b[i + 1][j];
		a[i + 2][j] = b[i][j];
		a[i + 1][j] = b[i][j + 1];

	}
	if (sign == '+')/*if sign + -> rotate clockwise*/
	{
		a[i][j + 2] = b[i][j];
		a[i + 1][j + 2] = b[i][j + 1];
		a[i + 2][j + 2] = b[i][j + 2];
		a[i + 2][j + 1] = b[i + 1][j + 2];
		a[i + 2][j] = b[i + 2][j + 2];
		a[i + 1][j] = b[i + 2][j + 1];
		a[i][j] = b[i + 2][j];
		a[i][j + 1] = b[i + 1][j];

	}

}
