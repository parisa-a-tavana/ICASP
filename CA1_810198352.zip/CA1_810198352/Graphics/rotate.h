void frotate(char sign, int region, char a[6][6]);
