#include"graphics.h"
char fgetsign()/*it's a function that gets sign input*/
{
	int finish = 0;
	char sign;
	while (finish == 0)
	{
		setcolor(15);
		outtextxy(650, 0, "enter sign");
		sign = getch();
		if (sign == '-' || sign == '+')/*if valid input :finish++ so we can come out of the loop*/
			finish++;
		else
			outtextxy(650, 100, "invalid input");
	}
	return sign;
}