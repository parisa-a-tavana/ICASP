char fgetsign();
/*it's a function that gets sign input*/