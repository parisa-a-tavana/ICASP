#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"structbuy.h"
#include"structgood.h"
#include"structsell.h"
#include"viewbuyer.h"
#include"viewseller.h"
#include"signupbuyer.h"
#include"signupseller.h"
#include"showgoods.h"
#include"purchasebuyer.h"
#include"loginbuyer.h"
#include"loginseller.h"
#include"getinput.h"
#include"countwords.h"
#include"checksignupseller.h"
#include"checksignupbuyer.h"
#include"checkinput.h"
#include"checkaddgoodsseller.h"
#include"buy.h"
#include"addgoodsseller.h"
int main()
{
	int i;
	int order_in_buyer_list;/*agar kasi ke login karde buyer bashad index ash ra neshan va agar -1 shod yani karabar nemitavanad login konad*/
	int order_in_seller_list;/*agar kasi ke login karde seller bashad index ash ra neshan va agar -1 shod yani karabar nemitavanad login konad*/
	struct buyer* user_buyer = (struct buyer*)malloc(sizeof(struct buyer));
	if (user_buyer == NULL)
	{
		printf("can not allocate memory\n");
		exit(0);
	}
	struct seller* user_seller = (struct seller*)malloc(sizeof(struct seller));
	if (user_seller == NULL)
	{
		printf("can not allocate memory\n");
		exit(0);
	}
	int num_buyer = 0;/*tedad buyer ke signup karde */
	int num_seller = 0;/*tedad seller hayi ke signup karde */
	int num_goods = 0;/*teded kol kalayae mojood ra midahad*/
	int login = 0;/* login 0->login nashode / 1->buyer / 2->seller  */
	int signupcheck = 0;/*0->mitavan signup kard !=0 ->nemitavan signup kard*/
	int check_adding_goods;/*0->kala bayad add shavad -1->error repeated 1->kala update shod*/
	int count_words;/*tedad kalamate vared shode baraye free kardan */
	char ** input;
	printf("WELCOM!PLEASE LOGIN/SIGNUP\n");
	while (1)
	{
		input = fgetinput();
		if (input != NULL)/*voroodi ha hich khataye type nadarand*/
		{
			if (login == 0)
			{
				if ((strcmp(input[0], "signup") == 0) && (strcmp(input[3], "buyer") == 0))
				{
					signupcheck = fcheck_signup_buyer(input, user_buyer, num_buyer);
					if (signupcheck == 0)
					{
						user_buyer = fsignup_buyer(input, user_buyer, num_buyer);
						num_buyer++;
					}
					else
					{
						printf("REPEATED USERNAME\n");
					}
				}
				else if ((strcmp(input[0], "signup") == 0) && (strcmp(input[3], "seller") == 0))
				{
					signupcheck = fcheck_signup_seller(input, user_seller, num_seller);
					if (signupcheck == 0)
					{
						user_seller = fsignup_seller(input, user_seller, num_seller);
						num_seller++;
					}
					else {
						printf("REPEATED USERNAME\n");
					}
				}
				else if ((strcmp(input[0], "login") == 0) && (strcmp(input[3], "buyer") == 0))
				{
					order_in_buyer_list = flogin_buyer(input, user_buyer, num_buyer);
					if (order_in_buyer_list == (-1))
					{
						printf("NO USER FOUND\n");
						login = 0;
					}
					else
						login = 1;
				}
				else if ((strcmp(input[0], "login") == 0) && (strcmp(input[3], "seller") == 0))
				{
					order_in_seller_list = flogin_seller(input, user_seller, num_seller);
					if (order_in_seller_list == (-1))
					{
						printf("NO USER FOUND\n");
						login = 0;
					}
					else
						login = 2;
				}
				else
				{
					printf("PLEASE LOGIN/SIGNUP FIRST\n");
				}

			}
			else/*if login 1,2->user has already logged in*/
			{
				if (strcmp(input[0], "logout") == 0)
				{
					printf("______________________________________________________\n");
					login = 0;
				}
				else if (strcmp(input[0], "show_goods") == 0)
				{
					fshow_goods(user_seller, num_seller);
				}
				else if ((strcmp(input[0], "view") == 0) && (login == 2))/*user_seller*/
				{

					fview_seller(user_seller, order_in_seller_list);
				}
				else if ((strcmp(input[0], "view") == 0) && (login == 1))/*user_buyer*/
				{
					fview_buyer(user_buyer, order_in_buyer_list);
				}
				else if ((strcmp(input[0], "buy") == 0) && (login == 1))
				{
					user_buyer = fbuy(input, user_seller, user_buyer, order_in_buyer_list, num_seller);
				}
				else if ((strcmp(input[0], "buy") == 0) && (login != 1))/*baraye gheyr az buyer->error */
				{
					printf("ONLY USERS WITH BUYER ROLE CAN USE THIS ORDER\n");
				}
				else if ((strcmp(input[0], "add_goods") == 0) && (login == 2))
				{
					check_adding_goods = fcheck_adding_goods_seller(input, user_seller, num_seller, order_in_seller_list);
					if (check_adding_goods == 0)/*kala bayad add shavad*/
					{
						user_seller = fadd_goods_seller(input, user_seller, num_seller, order_in_seller_list);
					}
					else if (check_adding_goods == (-1))
						printf("REAPEATED GOOD\n");
				}
				else if ((strcmp(input[0], "add_goods") == 0) && (login != 2))/*baraye gheyr az forooshande ->error*/
				{
					printf("ONLY USERS WITH SELLER ROLE CAN USE THIS ORDER\n");
				}
				else if ((strcmp(input[0], "deposite") == 0) && (login == 1))
				{
					user_buyer[order_in_buyer_list].user_buyer_accountmoney += atoi(input[1]);
				}
				else if ((strcmp(input[0], "deposite") == 0) && (login != 1))/*baraye gheyr az buyer->error*/
				{
					printf("ONLY USERS WITH BUYER ROLE CAN USE THIS ORDER\n");
				}
				else/*chon ghablan valid boodan input check shode ->user "login/signup" vared karde*/
				{
					printf("YOU HAVE ALREADY LOGGED IN\n");
				}
			}
			count_words = fcount_words(input[0]);
			for (i = 0;i < count_words;i++)
				free(input[i]);
		}
		else
			printf("INVALID INPUT\n");
		free(input);
	}
}