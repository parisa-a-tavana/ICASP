#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"structbuy.h"
#include"structsell.h"
#include"structgood.h"
struct seller* fadd_goods_seller(char** input, struct seller* user_seller, int num_seller, int order_in_seller_list)
{
	int numforsellgoods_user;
	numforsellgoods_user = user_seller[order_in_seller_list].num_for_sell_goods;/*tedad kalahayi ke az ghabl dashte=index kalaye jadid*/
	user_seller[order_in_seller_list].seller_goods = (struct goods*)realloc(user_seller[order_in_seller_list].seller_goods,
		(numforsellgoods_user + 1) * sizeof(struct goods));/*memory baraye kala*/
	if (user_seller[order_in_seller_list].seller_goods == NULL)
	{
		printf("can not allocate memory\n");
		exit(0);
	}
	user_seller[order_in_seller_list].seller_goods[numforsellgoods_user].goods_name = (char*)malloc((strlen(input[1]) + 1) * sizeof(char));
	if (user_seller[order_in_seller_list].seller_goods[numforsellgoods_user].goods_name == NULL)/*memory baraye name kala tedad char+\0*/
	{
		printf("can not allocate memory\n");
		exit(0);
	}
	strcpy(user_seller[order_in_seller_list].seller_goods[numforsellgoods_user].goods_name, input[1]);/*nam ra meghdar dehi (akhar input ghablan ba \0 baste shode*/
	user_seller[order_in_seller_list].seller_goods[numforsellgoods_user].goods_seller = (char*)malloc((strlen(user_seller[order_in_seller_list].user_seller_name) + 1) * sizeof(char));
	/*memory baraye name selller kala*/
	if (user_seller[order_in_seller_list].seller_goods[numforsellgoods_user].goods_seller == NULL)
	{
		printf("can not allocate memory\n");
		exit(0);
	}
	strcpy(user_seller[order_in_seller_list].seller_goods[numforsellgoods_user].goods_seller, user_seller[order_in_seller_list].user_seller_name);
	user_seller[order_in_seller_list].seller_goods[numforsellgoods_user].goods_count = atoi(input[3]);/*tedad kala ha */
	user_seller[order_in_seller_list].seller_goods[numforsellgoods_user].goods_price = atoi(input[2]);/*gheymat kala*/
	numforsellgoods_user++;
	user_seller[order_in_seller_list].num_for_sell_goods = numforsellgoods_user;
	return user_seller;
}
