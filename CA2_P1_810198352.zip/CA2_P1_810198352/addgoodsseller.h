struct seller* fadd_goods_seller(char** input, struct seller* user_seller, int num_seller, int order_in_seller_list);
/*kalaye jadid be seller ezafe dar struct array ash*/