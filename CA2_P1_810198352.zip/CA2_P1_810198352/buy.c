#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"structbuy.h"
#include"structsell.h"
#include"structgood.h"
#include"purchasebuyer.h"
struct buyer* fbuy(char**input, struct seller* user_seller, struct buyer* user_buyer, int order_in_buyer_list, int num_seller)
{
	int i, j;
	int check = 0;/*0->no item found   -1-> not enough product/money     1->you can buy*/
	int input_count_buyer = atoi(input[2]);/*tedad kala hayi ke buyer vared mikonad*/
	int goodsprice;
	if (num_seller > 0)
	{
		for (i = 0;i < num_seller;i++)
		{
			if ((strcmp(input[3], user_seller[i].user_seller_name) == 0) && (user_seller[i].num_for_sell_goods > 0))/*agar name yi ke buyer dade dar
																													list seller haye kala dar bashad */
				for (j = 0;j < user_seller[i].num_for_sell_goods;j++)
				{
					if (strcmp(input[1], user_seller[i].seller_goods[j].goods_name) == 0)/*agar good_name yi ke buyer dade ,dar list kala haye un seller bashad*/
					{/*seller va kalye un peyda shod hal shart kharid ra check mikonim*/
						if (input_count_buyer > user_seller[i].seller_goods[j].goods_count)
						{
							printf("NOT ENOUGH ITEMS FOUND\n");
							check = -1;
						}
						else if (user_buyer[order_in_buyer_list].user_buyer_accountmoney < (user_seller[i].seller_goods[j].goods_price*input_count_buyer))
						{
							printf("YOU DON'T HAVE ENOUGH MONEY\n");
							check = -1;
						}
						else if (input_count_buyer <= 0)
						{
							printf("YOU HAVE TO BUY AT LEAST 1\n");
							check = -1;
						}
						else/* buyer, kala va seller_name ra dorost vared karde va kala be endazeye kafi mojood va user pool kafi darad  */
						{
							check = 1;
							(user_seller[i].seller_goods[j].goods_count) -= input_count_buyer;
							goodsprice = user_seller[i].seller_goods[j].goods_price;
							(user_seller[i].user_seller_accountmoney) += (goodsprice*input_count_buyer);/*tghyirat  dar hesab seller*/
							(user_buyer[order_in_buyer_list].user_buyer_accountmoney) -= (goodsprice*input_count_buyer);/*taghyir dar tedad kalaha*/
							user_buyer = fpurchase_buyer(input, user_buyer, order_in_buyer_list, input_count_buyer, goodsprice);/*chon momken ast dakhel user_seller realloc va adress un avaz shavad*/
						}
					}


				}
		}

	}


	if (check == 0)
	{
		printf("NO ITEM MATCHED\n");
	}

	return user_buyer;/*momken ast dar kharid adress user_seller avaz shavad ->bayad return konim ta dar main ham adress avaz shavad vali tghyirat dar user_buyer adree un ra avaz nemikonad vachon pass byrefrebce hast moshkel nadarad*/
}