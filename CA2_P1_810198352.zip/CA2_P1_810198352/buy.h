struct buyer* fbuy(char**input, struct seller* user_seller, struct buyer* user_buyer, int order_in_buyer_list, int num_seller);
/*check mikonad ke emkan kharid hast ya na agar bood->seller ra update -agar kala ra buyer ghablan kharide bood->buyer update
agar kala baraye buyer jadid->baraye fpurchasebuyer miferestad ta memory allocate va information save*/
