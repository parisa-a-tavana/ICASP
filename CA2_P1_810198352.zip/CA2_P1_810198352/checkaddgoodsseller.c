#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"structbuy.h"
#include"structsell.h"
#include"structgood.h"
int fcheck_adding_goods_seller(char** input, struct seller* user_seller, int num_seller, int order_in_seller_list)
{
	int i, j;
	int check = 0;/*check 0->kala bayad add shavad -1->error repeated 1->kala update shod dar hamin function*/
	for (i = 0;i < num_seller;i++)/*(chon karbar login hast num_seller 0 nist) be ezaye har seller  \  dar kol in 2 loop had akser 1 bar yeki az shart ha true mishavad*/
	{
		if (user_seller[i].num_for_sell_goods > 0)/*agar seller i om chizi baraye foroosh gozashte bashad*/
		{
			for (j = 0;j < user_seller[i].num_for_sell_goods;j++)/*be ezaye har kalaye seller i om*/
			{
				if ((strcmp(input[1], user_seller[i].seller_goods[j].goods_name) == 0) &&/*agar kalaye karbar ba kalayi ke ghablan add shode yeki bashad */
					(strcmp(user_seller[order_in_seller_list].user_seller_name, user_seller[i].user_seller_name) != 0))/*vali seller name ha fargh kanad*/
					check = -1;
				else if ((strcmp(input[1], user_seller[i].seller_goods[j].goods_name) == 0) &&/*yani karbari ke login karde haman
																							  karbar i om va kalayi ke vared karde
																							  haman kalaye j om ast va hala update mishavad*/
					(strcmp(user_seller[order_in_seller_list].user_seller_name, user_seller[i].user_seller_name) == 0))
				{
					check = 1;
					user_seller[i].seller_goods[j].goods_count = atoi(input[3]);
				}

			}

		}

	}
	return check;
}