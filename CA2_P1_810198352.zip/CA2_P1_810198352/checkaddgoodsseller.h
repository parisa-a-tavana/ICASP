int fcheck_adding_goods_seller(char** input, struct seller* user_seller, int num_seller, int order_in_seller_list);
/*kala baraye add kardan ra check mikonad agar az ghabl bood->information ra update va 1 return
agar jadid bood-> 0 va agar error->-1 return */