#include<stdio.h>
#include<string.h>
#include<stdlib.h>


char**fcheckinput(char** input, int count_words)/*count_words->tedad kalame ha*/
{
	int i;
	int index_noghte;
	int count_char_number;/*vaghti user bayad int vared konad vali char vared kond tedad char ha ra mishemarad */
	int check = 0;/* -1 -> error*/
	if ((strcmp(input[0], "signup") != 0) && (strcmp(input[0], "login") != 0) && (strcmp(input[0], "logout") != 0) && (strcmp(input[0], "view") != 0)
		&& (strcmp(input[0], "deposite") != 0) && (strcmp(input[0], "add_goods") != 0) && (strcmp(input[0], "show_goods") != 0)
		&& (strcmp(input[0], "buy") != 0))/*agar dastoor eshtebahi benevisad->error*/
	{
		check = (-1);
	}
	int num_space_words = 0;
	for (i = 0;i < count_words;i++)
	{
		if (strlen(input[i]) == 0)
			num_space_words++;
	}
	if (num_space_words > 0)
	{
		check = (-1);
	}/*agar space ra be onvan voroodi dahad->error*/
	if ((strcmp(input[0], "signup") == 0) || (strcmp(input[0], "login") == 0))
	{
		if (count_words != 4)
			check = (-1);
		else if ((strcmp(input[3], "seller") != 0) && (strcmp(input[3], "buyer") != 0))/*chon else gozashtim motmaen hastim input3 vojood darad*/
		{
			check = (-1);
		}
	}
	if ((strcmp(input[0], "logout") == 0) || (strcmp(input[0], "view") == 0) || (strcmp(input[0], "show_goods") == 0))
	{
		if (count_words > 1)
			check = -1;
	}
	if (strcmp(input[0], "deposite") == 0)
	{
		if (count_words != 2)
			check = (-1);
		else/*midanim input1 vojood darad*/
		{
			for (i = 0;i < strlen(input[1]);i++)
				if ((input[1][i] > 57) || (input[1][i] < 48))/*agar adad vared nakarde bashad*/
				{
					check = (-1);
					break;
				}
		}


	}
	if (strcmp(input[0], "buy") == 0)
	{
		if (count_words != 4)
			check = (-1);
		else/*midanim input2 vojood darad*/
		{
			count_char_number = 0;/*dar ghesmati ke bayad adad vared konad chand char vared karde?*/
			for (i = 0;i < strlen(input[2]);i++)/*agar bejoz 0-9 vared konad*/
				if ((input[2][i] > 57) || (input[2][i] < 48))
					count_char_number++;
			if (count_char_number > 0)
				check = (-1);

		}

	}
	if (strcmp(input[0], "add_goods") == 0)
	{
		if (count_words != 4)
			check = (-1);
		else
		{
			count_char_number = 0;/*tedad kala int ast*/
			for (i = 0;i < strlen(input[3]);i++)/*agar goodscount kamelan adad nabashad->error*/
				if ((input[3][i] > 57) || (input[3][i] < 48))
					check = (-1);
			/*int bayad bashad*/

			for (i = 0;i < strlen(input[2]);i++)
				if ((input[2][i] > 57) || (input[2][i] < 48))
				{
					check = (-1);
					break;
				}
		}
	}


	if (check == (-1))/*agar check->-1 : bayad dobare voroodi dahad pas array ra free mikonim*/
	{
		for (int i = 0;i < count_words;i++)
			free(input[i]);
		input = NULL;
	}
	return input;

}