char**fcheckinput(char** input, int count_words);
/*input va kalame hayi ke vared shode ra migirad va check agar input !=valid->NULL return */