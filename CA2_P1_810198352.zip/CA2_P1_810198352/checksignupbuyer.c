#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"structbuy.h"
#include"structsell.h"
#include"structgood.h"
int fcheck_signup_buyer(char** input, struct buyer* user_buyer, int num_buyer)
{
	int signupcheck = 0;
	int i;
	if (num_buyer > 0)
	{
		for (i = 0;i < num_buyer;i++)
			if (strcmp(input[1], user_buyer[i].user_buyer_name) == 0)/*check mikonad ke username tekrari darim ya na*/
				signupcheck++;
	}
	return signupcheck;

}