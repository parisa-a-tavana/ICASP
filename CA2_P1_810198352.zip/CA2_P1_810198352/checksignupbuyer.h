int fcheck_signup_buyer(char** input, struct buyer* user_buyer, int num_buyer);
/*agar buyer mitavanad signup konad->0 va agar na >0 ra return mikonad*/