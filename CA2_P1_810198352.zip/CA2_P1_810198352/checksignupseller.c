#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"structbuy.h"
#include"structsell.h"
#include"structgood.h"
int fcheck_signup_seller(char** input, struct seller* user_seller, int num_seller)
{
	int signupcheck = 0;
	int i;
	if (num_seller > 0)
	{
		for (i = 0;i < num_seller;i++)
			if (strcmp(input[1], user_seller[i].user_seller_name) == 0)/*check mikonad ke username tekrari darim ya na*/
				signupcheck++;
	}
	return signupcheck;
}
