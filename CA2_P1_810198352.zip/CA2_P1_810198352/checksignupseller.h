int fcheck_signup_seller(char** input, struct seller* user_seller, int num_seller);
/*agar seller mitavanad signup konad->0 va agar na >0 ra return mikonad*/