#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int fcount_words(char*order)
{
	if ((strcmp(order, "signup") == 0) || (strcmp(order, "login") == 0) || (strcmp(order, "buy") == 0) || (strcmp(order, "add_goods") == 0))
		return 4;
	else if ((strcmp(order, "logout") == 0) || (strcmp(order, "view") == 0) || (strcmp(order, "show_goods") == 0))
		return 1;
	if (strcmp(order, "deposite") == 0)
		return 2;
}