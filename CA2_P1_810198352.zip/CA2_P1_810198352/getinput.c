#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"checkinput.h"
char** fgetinput()
{
	char* input = (char*)malloc(sizeof(char));
	if (input == NULL)
	{
		printf("can not allocate memory\n");
		exit(0);
	}
	char x;
	int i = 0; int j = 0; int k = 0;
	while (1)
	{
		x = getchar();
		if (x == '\n')
		{
			input[i] = '\0';
			break;
		}
		else
		{
			input[i] = x;
			i++;
			input = (char*)realloc(input, (i + 1) * sizeof(char));
			if (input == NULL)
			{
				printf("can not allocate memory\n");
				exit(0);
			}
		}
	}
	//input ra gereftim 
	int length = i;/*tedad harf haye voroodi*/
	int numofinput = 0;
	for (i = 0; i < length; i++)
		if (input[i] == ' ')
			numofinput++;
	numofinput++;/*tedad kalame ha*/
		
	char** user_input = (char**)malloc(sizeof(char*) * numofinput);
	if (user_input == NULL) {
		printf("can not allocate memory\n");
		exit(0);
	}
	for (i = 0; i < numofinput; i++)
	{
		user_input[i] = (char*)malloc(sizeof(char));
		if (user_input[i] == NULL) {
			printf("can not allocate memory\n");
			exit(0);
		}
	}
	i = 0; j = 0;
	for (int k = 0; k < length; k++)
	{
		if (input[k] != ' ')
		{
			j++;
			user_input[i] = (char*)realloc(user_input[i], (j + 10) * sizeof(char));
			if (user_input[i] == NULL) {
				printf("can not allocate memory\n");
				exit(0);
			}
			user_input[i][j - 1] = input[k];
		}
		else if (input[k] == ' ')
		{
			user_input[i][j] = '\0';
			j = 0;
			i++;
		}
	}
	user_input[i][j] = '\0';/*kalame ha ra dar user_input gereftim*/
	/*user input yek araye 2 bodi ke 1 bod kalame 1 bod harf har kalame*/
	user_input = fcheckinput(user_input, numofinput);/*check mikonad voroodi valid ya na*/


	free(input);
	return user_input;



}