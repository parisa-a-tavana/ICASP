char** fgetinput();
/*voroodi ra migirad va ba checkinput dakhel ash valid boodan ra check mikonad agar !=valid->NULL midahad*/
