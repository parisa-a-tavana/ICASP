#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"structbuy.h"
#include"structsell.h"
#include"structgood.h"
int flogin_buyer(char** input, struct buyer* user_buyer, int num_buyer)
{
	int i;
	int order_in_buyer_list = -1;/*index baraye struct ra midahad va agar -1 shod yani karabar nemitavanad login konad*/
	if (num_buyer > 0)/*agar 0 bood yani  ta hala kasi signup nakarde ->error*/
	{
		for (i = 0;i < num_buyer;i++)
			if ((strcmp(input[1], user_buyer[i].user_buyer_name) == 0) &&/*dar list buyer ha user_buyer ra peyda mikonad*/
				(strcmp(input[2], user_buyer[i].user_buyer_password) == 0))
			{
				order_in_buyer_list = i;
				break;
			}
	}
	/*agar fard peyda nashavad order_in_buyer_list -1 mimanad->error*/
	return order_in_buyer_list;
}