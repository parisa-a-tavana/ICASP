int flogin_buyer(char** input, struct buyer* user_buyer, int num_buyer);
/*check mikonad ke fard mitavanad login lonad ya na agar mitavanad->index user ra dar array buyer ha midahad va agar nemitavanad->-1 */
