#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"structbuy.h"
#include"structsell.h"
#include"structgood.h"
int flogin_seller(char** input, struct seller* user_seller, int num_seller)
{
	int i;
	int order_in_seller_list = -1;/*index baraye struct ra midahad va agar -1 shod yani karabar nemitavanad login konad*/
	if (num_seller > 0)/*yani ta hala seller yi signup nakarde*/
	{
		for (i = 0;i < num_seller;i++)
			if ((strcmp(input[1], user_seller[i].user_seller_name) == 0) &&/*dar list seller ha user_seller ra peyda mikonim*/
				(strcmp(input[2], user_seller[i].user_seller_password) == 0))
			{
				order_in_seller_list = i;
				break;
			}
	}
	/*agar fard peyda nashavad order_in_seller_list -1 mimanad->error*/
	return order_in_seller_list;
}
