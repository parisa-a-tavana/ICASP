#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"structbuy.h"
#include"structsell.h"
#include"structgood.h"
struct buyer* fpurchase_buyer(char** input, struct buyer* user_buyer, int order_in_buyer_list, int input_count_buyer, int goodsprice)
{
	int exist = 0;/*0->kala jadid 1->ghablan ham kharide bode*/
	int i;

	if (user_buyer[order_in_buyer_list].num_bought_goods > 0)/*agar buyer ghablan kharid dashte*/
	{
		for (i = 0;i < user_buyer[order_in_buyer_list].num_bought_goods;i++)
		{
			if (strcmp(user_buyer[order_in_buyer_list].buyer_goods[i].goods_name, input[1]) == 0)/*agar karbar kala ra ghablan kharide bood*/
			{
				(user_buyer[order_in_buyer_list].buyer_goods[i].goods_count) += input_count_buyer;/*be tedadi ke vared karde eazafe kon be mojoodi kala*/
				exist = 1;
				break;
			}
		}
	}
	if (exist != 1)/*kalayi ke mikhahad bekharad jadid ast va bayad barayash memory ekhtesas dahim*/
	{
		int numofbought = user_buyer[order_in_buyer_list].num_bought_goods;/*tedad kalahayi ke az ghabl kharide */
		user_buyer[order_in_buyer_list].buyer_goods = (struct goods*)realloc(user_buyer[order_in_buyer_list].buyer_goods,
			(numofbought + 1) * sizeof(struct goods));
		if (user_buyer[order_in_buyer_list].buyer_goods == NULL)
		{
			printf("can not allocate memory");
			exit(0);
		}
		user_buyer[order_in_buyer_list].buyer_goods[numofbought].goods_name = (char*)malloc((strlen(input[1]) + 1) * sizeof(char));
		if (user_buyer[order_in_buyer_list].buyer_goods[numofbought].goods_name == NULL)/*baraye name kala*/
		{
			printf("can not allocate memory");
			exit(0);
		}
		strcpy(user_buyer[order_in_buyer_list].buyer_goods[numofbought].goods_name, input[1]);/*name ra save mikonad*/
		user_buyer[order_in_buyer_list].buyer_goods[numofbought].goods_seller = (char*)malloc((strlen(input[3] + 1) * sizeof(char)));/*baraye name 
																																	 seller kala*/
		if (user_buyer[order_in_buyer_list].buyer_goods[numofbought].goods_seller == NULL)
		{
			printf("can not allocate memory");
			exit(0);
		}
		strcpy(user_buyer[order_in_buyer_list].buyer_goods[numofbought].goods_seller, input[3]);/*name forooshande ra save*/
		user_buyer[order_in_buyer_list].buyer_goods[numofbought].goods_count = input_count_buyer;
		user_buyer[order_in_buyer_list].buyer_goods[numofbought].goods_price = goodsprice;
		numofbought++;/*tedad noe kala ha ziad mishavad*/
		user_buyer[order_in_buyer_list].num_bought_goods = numofbought;



	}
	return user_buyer;/*momken ast realloc shavad va adress un avaz shavad*/
}
