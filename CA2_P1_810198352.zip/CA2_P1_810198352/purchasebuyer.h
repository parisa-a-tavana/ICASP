struct buyer* fpurchase_buyer(char** input, struct buyer* user_buyer, int order_in_buyer_list, int input_count_buyer, int goodsprice);
/*vaghti buyer kalayi kharid struct ash ra update mikonad*/