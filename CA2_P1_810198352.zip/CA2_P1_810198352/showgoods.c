#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"structbuy.h"
#include"structsell.h"
#include"structgood.h"
void fshow_goods(struct seller*  user_seller, int num_seller)
{
	int i, j;
	if (num_seller > 0)/*agar had aghal 1 seller dashte bashim*/
	{
		for (i = 0;i < num_seller;i++)/*baraye har seller agar had aghal 1 kala dashte bashad namayesh midahad*/
		{
			if (user_seller[i].num_for_sell_goods>0)
				for (j = 0;j < user_seller[i].num_for_sell_goods;j++)
				{
					printf("name of product: %s \t price: %d \t number of products: %d \t seller: %s\n",
						user_seller[i].seller_goods[j].goods_name, user_seller[i].seller_goods[j].goods_price,
						user_seller[i].seller_goods[j].goods_count, user_seller[i].user_seller_name);
				}
		}
	}

}
