void fshow_goods(struct seller*  user_seller, int num_seller);
/*tamame kala haye tamam seller ha ra print*/