#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"structbuy.h"
#include"structsell.h"
#include"structgood.h"
struct buyer* fsignup_buyer(char** input, struct buyer* user_buyer, int num_buyer)
{
	user_buyer = (struct buyer*)realloc(user_buyer, (num_buyer + 1) * sizeof(struct buyer));/*khod struct buyer realloc mishe*/
	if (user_buyer == NULL)
	{
		printf("can not allocate memory\n");
		exit(0);
	}
	user_buyer[num_buyer].user_buyer_name = (char*)malloc(sizeof(char)*(strlen(input[1]) + 1));/*name malloc */
	if (user_buyer[num_buyer].user_buyer_name == NULL)

	{
		printf("can not allocate memory\n");
		exit(0);
	}
	strcpy(user_buyer[num_buyer].user_buyer_name, input[1]);/*va meghdar dehi*/
	user_buyer[num_buyer].user_buyer_password = (char*)malloc(sizeof(char)*(strlen(input[2]) + 1));/*password malloc*/
	if (user_buyer[num_buyer].user_buyer_password == NULL)
	{
		printf("can not allocate memory\n");
		exit(0);
	}
	strcpy(user_buyer[num_buyer].user_buyer_password, input[2]);/*va meghdardehi input khodesh \0 rodare*/
	user_buyer[num_buyer].user_buyer_role = (char*)malloc(6 * sizeof(char));/*role malloc(moshakas ast meghdare memory ash*/
	if (user_buyer[num_buyer].user_buyer_role == NULL)
	{
		printf("can not allocate memory\n");
		exit(0);
	}
	strcpy(user_buyer[num_buyer].user_buyer_role, "buyer");/*meghdar dehi*/
	user_buyer[num_buyer].user_buyer_role[5] = '\0';/*tahesham vase etminan mibandim*/
	user_buyer[num_buyer].user_buyer_accountmoney = 0;
	user_buyer[num_buyer].num_bought_goods = 0;
	user_buyer[num_buyer].buyer_goods = (struct goods*)malloc(sizeof(struct goods));
	if (user_buyer[num_buyer].buyer_goods == NULL)/*struct baraye kalahayi ke dar ayande mikharad*/
	{
		printf("can not allocate memory\n");
		exit(0);
	}
	return user_buyer;
}