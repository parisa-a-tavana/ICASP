struct buyer* fsignup_buyer(char** input, struct buyer* user_buyer, int num_buyer);
/*arrey struct buyer ha ra ba voroodi va tedad buyer haye signup karde update mikonad */