#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"structbuy.h"
#include"structsell.h"
#include"structgood.h"
struct seller* fsignup_seller(char** input, struct seller* user_seller, int num_seller)
{
	user_seller = (struct seller*)realloc(user_seller, (num_seller + 1) * sizeof(struct seller));/*khode struct seller malloc*/
	if (user_seller == NULL)
	{
		printf("can not allocate memory");
		exit(0);
	}
	user_seller[num_seller].user_seller_name = (char*)malloc(sizeof(char)*(strlen(input[1]) + 1));/*username malloc*/
	if (user_seller[num_seller].user_seller_name == NULL)
	{
		printf("can not allocate memory");
		exit(0);
	}
	strcpy(user_seller[num_seller].user_seller_name, input[1]);/*va meghdar dehi*/
	user_seller[num_seller].user_seller_password = (char*)malloc(sizeof(char)*strlen(input[2]) + 1);/*password malloc*/
	if (user_seller[num_seller].user_seller_password == NULL)
	{
		printf("can not allocate memory");
		exit(0);
	}
	strcpy(user_seller[num_seller].user_seller_password, input[2]);/*meghdar dehi password*/
	user_seller[num_seller].user_seller_role = (char*)malloc(7 * sizeof(char));/*role moshakas ast cheghadr memoty mikhahad*/
	if (user_seller[num_seller].user_seller_role == NULL)
	{
		printf("can not allocate memory");
		exit(0);
	}
	strcpy(user_seller[num_seller].user_seller_role, "seller");
	user_seller[num_seller].user_seller_role[6] = '\0';
	user_seller[num_seller].user_seller_accountmoney = 0;
	user_seller[num_seller].num_for_sell_goods = 0;
	user_seller[num_seller].seller_goods = (struct goods*)malloc(sizeof(struct goods));
	if (user_seller[num_seller].seller_goods == NULL)
	{
		printf("can not allocate memory");
		exit(0);
	}
	return user_seller;
}