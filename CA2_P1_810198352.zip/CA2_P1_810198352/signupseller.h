struct seller* fsignup_seller(char** input, struct seller* user_seller, int num_seller);
/*arrey struct seller ha ra ba voroodi va tedad seller haye signup karde update mikonad */