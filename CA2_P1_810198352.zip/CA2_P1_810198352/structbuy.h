struct buyer
{
	char* user_buyer_name;
	char* user_buyer_password;
	char* user_buyer_role;
	int user_buyer_accountmoney;
	struct goods* buyer_goods;
	int num_bought_goods;/*chand no kala kharide*/


};