struct goods {
	char*goods_seller;
	char*goods_name;
	int goods_price;
	int goods_count;


};
