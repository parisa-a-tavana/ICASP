struct seller {
	char*user_seller_name;
	char*user_seller_password;
	char*user_seller_role;
	int user_seller_accountmoney;
	struct goods* seller_goods;
	int num_for_sell_goods;/*chand no kala baraye foroosh*/
};
