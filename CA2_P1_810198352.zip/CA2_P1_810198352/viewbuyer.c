#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"structbuy.h"
#include"structsell.h"
#include"structgood.h"
void fview_buyer(struct buyer* user_buyer, int order_in_buyer_list)
{
	int i;
	printf("username: %s \n", user_buyer[order_in_buyer_list].user_buyer_name);
	printf("role: %s \n", user_buyer[order_in_buyer_list].user_buyer_role);
	printf("account balance: %d \n", user_buyer[order_in_buyer_list].user_buyer_accountmoney);
	if (user_buyer[order_in_buyer_list].num_bought_goods>0)
		for (i = 0;i < user_buyer[order_in_buyer_list].num_bought_goods;i++)/*agar kalayi darad namayesh midahad*/
		{
			printf("name of product:%s \t price:%d \t number of products:%d \t seller name:%s \n",
				user_buyer[order_in_buyer_list].buyer_goods[i].goods_name, user_buyer[order_in_buyer_list].buyer_goods[i].goods_price,
				user_buyer[order_in_buyer_list].buyer_goods[i].goods_count, user_buyer[order_in_buyer_list].buyer_goods[i].goods_seller);
		}
}
