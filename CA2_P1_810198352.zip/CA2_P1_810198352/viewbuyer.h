void fview_buyer(struct buyer* user_buyer, int order_in_buyer_list);
/*index buyer login karde va arrey struct ha ra migirad va information user ra print */