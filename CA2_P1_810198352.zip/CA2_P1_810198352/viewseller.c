#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"structbuy.h"
#include"structsell.h"
#include"structgood.h"
void fview_seller(struct seller* user_seller, int order_in_seller_list)
{
	int i;
	printf("username: %s \n", user_seller[order_in_seller_list].user_seller_name);
	printf("role: %s \n", user_seller[order_in_seller_list].user_seller_role);
	printf("account balance: %d \n", user_seller[order_in_seller_list].user_seller_accountmoney);
	if (user_seller[order_in_seller_list].num_for_sell_goods > 0)
	{
		for (i = 0;i < user_seller[order_in_seller_list].num_for_sell_goods;i++)
		{
			printf("name of product:%s \t price:%d \t number of products:%d \n",/*agar kalayi darad namayesh midahad*/
				user_seller[order_in_seller_list].seller_goods[i].goods_name, user_seller[order_in_seller_list].seller_goods[i].goods_price,
				user_seller[order_in_seller_list].seller_goods[i].goods_count);
		}
	}
}