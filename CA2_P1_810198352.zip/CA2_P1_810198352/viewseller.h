void fview_seller(struct seller* user_seller, int order_in_seller_list);
/*index seller login karde va arrey struct ha ra migirad va information user ra print */