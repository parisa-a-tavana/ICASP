#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h"
#include"addgoods.h"
#include"addsearchnode.h"
#include"buy.h"
#include"changeprice.h"
#include"checkinput.h"
#include"checksearch.h"
#include"checksignupbuyer.h"
#include"checksignupseller.h"
#include"countwords.h"
#include"deletebuyernode.h"
#include"deletesellernode.h"
#include"deletenode.h"
#include"editsearch.h"
#include"freeall.h"
#include"freesearch.h"
#include"getinput.h"
#include"loginbuyer.h"
#include"loginseller.h"
#include"makesearch.h"
#include"rate.h"
#include"readgoodsfile.h"
#include"readuserfile.h"
#include"removegoods.h"
#include"showgoods.h"
#include"showsearch.h"
#include"signupbuyer.h"
#include"signupseller.h"
#include"viewbuyer.h"
#include"viewseller.h"
#include"writegoodsfile.h"
#include"writeuserfile.h"
int main()
{
	struct seller* head_seller = (struct seller*)malloc(sizeof(struct seller));/*list of all sellers*/
	if (head_seller == NULL)
	{
		printf("can not allocate memory");
		exit(0);
	}
	head_seller->next = NULL;/*first node is a dummy node*/
	struct buyer* head_buyer = (struct buyer*)malloc(sizeof(struct buyer));/*list of all buyers*/
	if (head_buyer == NULL)
	{
		printf("can not allocate memory");
		exit(0);
	}
	head_buyer->next = NULL;/*first node is a dummy node*/
	struct goods* head_goods_buyer = (struct goods*)malloc(sizeof(struct goods));/*list of all sold goods*/
	if (head_goods_buyer == NULL)
	{
		printf("can not allocate memory");
		exit(0);
	}
	head_goods_buyer->next = NULL;/*first node is a dummy node*/
	struct goods* head_goods_seller = (struct goods*)malloc(sizeof(struct goods));/*list of all for_sale goods*/
	if (head_goods_seller == NULL)
	{
		printf("can not allocate memory");
		exit(0);
	}
	head_goods_seller->next = NULL;/*first node is a dummy node*/
	struct goods* head_search = (struct goods*)malloc(sizeof(struct goods));/*a list for searching*/
	if (head_search == NULL)
	{
		printf("can not allocate memory");
		exit(0);
	}
	head_search->next = NULL;/*first node  is a dummy node*/
	struct buyer* current_b;/*baraye search dar list b->buyer*/
	struct seller* current_seller_user;/*zakhire etelate karbar dar zamane login agar NULL->login error*/
	struct buyer* current_buyer_user;/*zakhire etelate karbar dar zamane login  agar NULL->login error*/
	char** input;
	int check_signup;/*0->mitavanad signup konad >0->nemitavanad signup konad*/
	int i;
	int login = 0;/*  0->login nashode / 1->buyer / 2->seller  */
	int search_num;/*ba chand vijhegi search mikonad*/
	int count_words;/*chand ta kalame vared kardi*/
	int check_search;/*0->repeated 1->name  2->min_price  4->max_price   8->seller_username*/
	int search_input_holder;/* adadi bianery ke goods_attribute ha ra zakhire mikonad*/
	FILE *user = fopen("user.txt", "a+");
	if (user == NULL)
	{
		printf("can not open file\n");
		exit(0);
	}
	fread_file_usere(user, head_seller, head_buyer);
	fclose(user);
	FILE* goods = fopen("goods.txt", "a+");
	if (goods == NULL)
	{
		printf("can not open file\n");
		exit(0);
	}
	fread_file_goods(goods, head_goods_seller, head_goods_buyer);
	fclose(goods);
	/*ta hala az file ha khandim*/
	printf("WELCOME PLEASE SIGNUP/LOGIN\n");
	while (1)
	{
		input = fgetinput();

		if (input != NULL)/*order is valid*/
		{
			if (strcmp(input[0], "exit") == 0)
			{
				break;
			}
			if (login == 0) /*not logged in*/
			{
				if ((strcmp(input[0], "signup") == 0) && (strcmp(input[3], "buyer") == 0))
				{
					check_signup = fcheck_signup_buyer(head_buyer, input);
					if (check_signup == 0)
					{
						fsignup_buyer(head_buyer, input);
					}
					else
						printf("REPEATED USER\n");
				}
				else if ((strcmp(input[0], "signup") == 0) && (strcmp(input[3], "seller") == 0))
				{
					check_signup = fcheck_signup_seller(head_seller, input);
					if (check_signup == 0)
					{
						fsignup_seller(head_seller, input);
					}
					else
						printf("REPEATED USER\n");
				}
				else if ((strcmp(input[0], "login") == 0) && (strcmp(input[3], "buyer") == 0))
				{
					current_buyer_user = flogin_buyer(head_buyer, input);
					if (current_buyer_user == NULL)
					{
						login = 0;
						printf("PLEASE SIGNUP FIRST\n");
					}
					else
					{
						login = 1;
						printf("YOU LOGGED IN\n");
					}
				}
				else if ((strcmp(input[0], "login") == 0) && (strcmp(input[3], "seller") == 0))
				{
					current_seller_user = flogin_seller(head_seller, input);
					if (current_seller_user == NULL)
					{
						login = 0;
						printf("PLEASE SIGNUP FIRST\n");
					}
					else
					{
						login = 2;
						printf("YOU LOGGED IN\n");
					}
				}
				else
				{
					printf("PLEAS LOGIN FIRST\n");
				}
			}
			else
			{
				if ((strcmp(input[0], "view") == 0) && (login == 2))/*seller*/
				{
					fview_seller(current_seller_user, head_goods_seller);
				}
				else if ((strcmp(input[0], "view") == 0) && (login == 1))
				{
					fview_buyer(current_buyer_user, head_goods_buyer);
				}
				else if ((strcmp(input[0], "add_goods") == 0) && (login == 2))

				{
					head_goods_seller = fadd_goods(head_goods_seller, current_seller_user, input);
				}
				else if ((strcmp(input[0], "add_goods") == 0) && (login != 2))/*baraye gheyr az forooshande ->error*/
				{
					printf("ONLY USERS WITH SELLER ROLE CAN USE THIS ORDER\n");
				}
				else if ((strcmp(input[0], "remove_goods") == 0) && (login == 2))
				{
					head_goods_seller = fremove_goods(head_goods_seller, current_seller_user, input);
				}
				else if ((strcmp(input[0], "remove_goods") == 0) && (login != 2))/*baraye gheyr az forooshande ->error*/
				{
					printf("ONLY USERS WITH SELLER ROLE CAN USE THIS ORDER\n");
				}
				else if ((strcmp(input[0], "change_goods_price") == 0) && (login == 2))
				{
					fchange_price(head_goods_seller, current_seller_user, input);
				}
				else if ((strcmp(input[0], "rate_goods") == 0) && (login == 1))
				{
					frate(head_goods_seller, head_goods_buyer, current_buyer_user, input);
				}
				else if ((strcmp(input[0], "rate_goods") == 0) && (login != 1))/*baraye gheyr az forooshande ->error*/
				{
					printf("ONLY USERS WITH BUYER ROLE CAN USE THIS ORDER\n");
				}
				else if (strcmp(input[0], "show_goods") == 0)
				{
					fshow_goods(head_goods_seller);
				}
				else if ((strcmp(input[0], "deposit") == 0) && (login == 1))
				{
					current_buyer_user->user_buyer_accountmoney += atoi(input[1]);
					printf("YOU DEPOSITED MONEY\n");
				}
				else if ((strcmp(input[0], "buy") == 0) && (login == 1))
				{
					fbuy(current_buyer_user, head_seller, head_goods_seller, head_goods_buyer, input);
				}
				else if (strcmp(input[0], "search") == 0)
				{

					search_num = atoi(input[1]);
					if ((search_num > 0) && (search_num<5))
					{
						search_input_holder = 0;

						count_words = fcount_words(input[0]);
						for (i = 0; i < count_words; i++)
							free(input[i]);
						free(input);
						printf("WHRITE THE CONDITIONS:\n");
						input = fgetinput();
						if (input != NULL)
						{
							if ((strcmp(input[0], "max_price") == 0) || (strcmp(input[0], "min_price") == 0)
								|| (strcmp(input[0], "name") == 0) || (strcmp(input[0], "seller_username") == 0))
							{
								search_input_holder = fcheck_search(search_input_holder, input);/*avalin voroodi tekrari nist*/
								head_search = fmake_search_list(input, head_goods_seller, head_search);
								search_num--;/*if search_num=1->badan input free mishavad*/
								while (search_num > 0)
								{
									count_words = fcount_words(input[0]);
									for (i = 0; i < count_words; i++)
										free(input[i]);
									free(input);/*dar kharin bar ke search_num 0 mishavad input badan free mishavad kharej loop jayi ke hameye input ha free mishavad*/
									printf("WRITE THE CONDITIONS:\n");
									input = fgetinput();
									if (input != NULL)
									{
										if ((strcmp(input[0], "max_price") == 0) || (strcmp(input[0], "min_price") == 0)
											|| (strcmp(input[0], "name") == 0) || (strcmp(input[0], "seller_username") == 0))
										{
											check_search = fcheck_search(search_input_holder, input);
											if (check_search > 0)
											{
												search_input_holder += check_search;
												head_search = fedit_search_list(input, head_search);
												search_num--;
											}
											else
												printf("REPEATED GOODS_ATTRIBUTE PLEASE WRITE A NEW ONE\n");
										}
										else
										{
											printf("INVALID CONDITION PLEASE WRITE YOUR CONDITON AGAIN\n");
										}
									}
									else
									{
										printf("INVALID INPUT\n HERE IS YOUR SEARCH RESULT BASED ON PREVIOUS CONDITIONS\n IF YOU WANT, SEARCH AGAIN\n");
										break;
									}

								}
								fshow_search_result(head_search);
								head_search = ffree_search_list(head_search);
								int we = 10;
							}
							else
							{
								printf("INVALID CONDITION IF YOU WANT, SEARCH AGAIN\n");
								/*bayad dobare search ra ba num_conditions vared konad*/
							}
						}
						else
							printf("INVALID INPUT IF YOU WANT, SEARCH AGAIN\n");



					}
					else
					{
						printf("YOU CAN HAVE 1-4 CONDITIONS\n");
					}
				}

				else if (strcmp(input[0], "logout") == 0)
				{
					printf("______________________________________________________\n");
					login = 0;
				}
				else
				{
					printf("YOU CAN'T ACCESS THIS ORDER\n");
				}
			}
			fopen("user.txt", "w");
			fwrite_file_user(user, head_seller, head_buyer);
			fclose(user);
			fopen("goods.txt", "w");
			fwrite_file_goods(goods, head_goods_seller, head_goods_buyer);
			fclose(goods);
			if (input != NULL)
			{
				count_words = fcount_words(input[0]);
				for (i = 0; i < count_words; i++)
					free(input[i]);
			}
			free(input);

		}
		else
		{
			printf("INVALID INPUT\n");
			free(input);
		}

	}
	if (input != NULL)
	{
		count_words = fcount_words(input[0]);
		for (i = 0; i < count_words; i++)
			free(input[i]);
	}
	free(input);
	freee(head_goods_buyer, head_goods_seller, head_buyer, head_seller);
	ffree_search_list(head_search);
	free(head_buyer);
	free(head_seller);
	free(head_search);
	free(head_goods_buyer);
	free(head_goods_seller);
	printf("YOU EXITED THE PROGRAMME\n");
}