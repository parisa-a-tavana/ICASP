#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h" 
struct goods* fadd_goods(struct goods* head_goods_seller, struct seller* current_seller_user, char** input)
{
	int check = 0;/*0->new-node 1->update -1->error*/
	int price;
	struct goods* temp;
	struct goods* preve_temp;
	temp = head_goods_seller->next;
	while (temp != NULL)
	{
		if ((strcmp(input[1], temp->goods_name) == 0) && (strcmp(current_seller_user->user_seller_name, temp->goods_seller) != 0))/*name kala hast vali current user ,seller nist*/
		{
			check = -1;
			printf("REPEATED PRODUCT\n");
			break;
		}
		else if ((strcmp(input[1], temp->goods_name) == 0) && (strcmp(current_seller_user->user_seller_name, temp->goods_seller) == 0))/*current_user
																																	   ghablan in kala ra add karde bood
																																	   ->temp*/
		{
			price = atoi(input[2]);
			if (temp->goods_price != price)
			{
				check = -1;
				printf("PRICE DOESN'T MATCH\n");
				break;
			}
			else/*tedad ra update kon*/
			{
				check = 1;
				temp->goods_count += atoi(input[3]);
				break;
			}
		}
		temp = temp->next;
	}
	if (check == 0)/*add new node*/
	{
		struct goods* new_node = (struct goods*)malloc(sizeof(struct goods));
		if (new_node == NULL)
		{
			printf("can not allocate memory");
			exit(0);
		}
		new_node->goods_name = (char*)malloc((strlen(input[1]) + 1) * sizeof(char));
		if (new_node->goods_name == NULL)
		{
			printf("can not allocate memory");
			exit(0);
		}
		strcpy(new_node->goods_name, input[1]);
		new_node->goods_seller = (char*)malloc((strlen(current_seller_user->user_seller_name) + 1) * sizeof(char));
		if (new_node->goods_seller == NULL) {
			printf("can not allocate memory");
			exit(0);
		}
		strcpy(new_node->goods_seller, current_seller_user->user_seller_name);
		new_node->goods_owner = (char*)malloc((strlen(current_seller_user->user_seller_name) + 1) * sizeof(char));
		if (new_node->goods_owner == NULL)
		{
			printf("can not allocate memory");
			exit(0);
		}
		strcpy(new_node->goods_owner, current_seller_user->user_seller_name);
		new_node->goods_price = atoi(input[2]);
		new_node->goods_count = atoi(input[3]);
		new_node->count_rater = 0;
		new_node->sum_rate = 0;
		temp = head_goods_seller->next;
		preve_temp = head_goods_seller;
		while ((temp != NULL) && (strcmp(temp->goods_name, new_node->goods_name) < 0))
		{
			temp = temp->next;
			preve_temp = preve_temp->next;
		}
		new_node->next = preve_temp->next;
		preve_temp->next = new_node;

	}
	if (check >= 0)
		printf("PRODUCT ADDED\n");
	return head_goods_seller;
}