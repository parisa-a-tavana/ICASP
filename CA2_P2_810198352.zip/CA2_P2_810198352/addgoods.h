struct goods* fadd_goods(struct goods* head_goods_seller, struct seller* current_seller_user, char** input);
/*kalaye jadid be list for_sale goods ezafe*/
