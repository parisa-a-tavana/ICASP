#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h" 
struct goods* fadd_search_node(struct goods* head_search, struct goods* new_search_node)
{/*new_node ra dar jaye monaseb dar kist migozarad*/
	struct goods*current;
	struct goods* prev;
	prev = head_search;
	current = head_search->next;
	while ((current != NULL) && (strcmp(current->goods_name, new_search_node->goods_name) < 0))
	{
		prev = prev->next;
		current = current->next;
	}
	prev->next = new_search_node;
	new_search_node->next = current;
	return head_search;

}