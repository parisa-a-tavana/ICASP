struct goods* fadd_search_node(struct goods* head_search, struct goods* new_search_node);
/*new_node ra dar jaye monaseb dar kist migozarad*/