#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h" 
void fbuy(struct buyer* current_user_buyer, struct seller* head_seller, struct goods* head_goods_seller, struct goods* head_goods_buyer, char** input)
{
	int check = 0;
	/*pasvand haye g->kholase good s->kholase seller b->kholase buyer hast*/
	int count_g = atoi(input[2]);/*tedad kalaha*/
	struct goods* temp_gs;/*product ra az head_goods_seller peyda mikonad*/
	struct goods* temp_gb;/*agar hamin kala ra buyer ghablan kharide bood peyda mikonad*/
	struct seller* temp_seller;/*product_seller ra peyda mikonad*/
	temp_seller = head_seller->next;
	while (temp_seller != NULL)/*forooshande ra peyda kon baraye account money*/
	{
		if (strcmp(temp_seller->user_seller_name, input[3]) == 0)
		{
			break;
		}
		temp_seller = temp_seller->next;
	}
	if (temp_seller != NULL)
	{
		temp_gs = head_goods_seller->next;
		while (temp_gs != NULL)/*kala ra peyda kon*/
		{
			if ((strcmp(temp_gs->goods_name, input[1]) == 0) && (strcmp(temp_gs->goods_seller, input[3]) == 0))
			{
				break;
			}
			temp_gs = temp_gs->next;
		}
	}

	if ((temp_seller != NULL) && (temp_gs != NULL))/*agar kala va forooshande mored nazar vojood darad*/
	{
		if (temp_gs->count_rater >= 5)/*raiting */
		{
			float rate = temp_gs->sum_rate;
			float ave = rate / temp_gs->count_rater;
			if (ave<2)
			{
				printf("DUE TO LOW RANKING PRODUCT IS NOT AVAILABLE\n");
				check = -1;
			}
		}
		else if (count_g <= 0)
		{
			printf("YOU HAVE TO BUY AT LEAST 1 ITEM\n");
			check = -1;
		}
		else if (temp_gs->goods_count < count_g)
		{
			printf("NOT ENOUGH ITEMS FOUND\n");
			check = -1;
		}
		else if ((current_user_buyer->user_buyer_accountmoney) < (count_g*temp_gs->goods_price))
		{
			printf("YOU DON'T HAVE ENOUGH MONEY\n");
			check = -1;
		}


	}
	if ((temp_seller == NULL) || (temp_gs == NULL))
	{
		printf("NO PRODUCT FOUND TO BE SOLD\n ");
		check = -1;
	}
	if (check != (-1))
	{

		temp_seller->user_seller_accountmoney += (atoi(input[2]))*count_g;
		temp_gs->goods_count -= (atoi(input[2]));
		current_user_buyer->user_buyer_accountmoney -= (atoi(input[2]))*count_g;
		temp_gb = head_goods_buyer->next;
		while (temp_gb != NULL)
		{/*agar buyer ghablan in kala ra az hamin forooshane va ba hamin price kharide*/
			if ((strcmp(temp_gb->goods_name, input[1]) == 0) && (strcmp(temp_gb->goods_seller, input[3]) == 0) &&
				(strcmp(temp_gb->goods_owner, current_user_buyer->user_buyer_name) == 0) && (temp_gb->goods_price == temp_gs->goods_price))
			{
				break;
			}

			temp_gb = temp_gb->next;

		}
		if (temp_gb != NULL)
		{
			temp_gb->goods_count += count_g;
			temp_gb->count_rater = 0;/*be ezaye har kharid mitavanad rate konad*/
			temp_gb->sum_rate = 0;
			printf("YOU BOUGHT THE ITEM\n");
		}
		else
		{
			struct goods* new_good_node = (struct goods*)malloc(sizeof(struct goods));
			if (new_good_node == NULL)
			{
				printf("can not allocate memory");
				exit(0);
			}
			new_good_node->goods_name = (char*)malloc((strlen(input[1]) + 1) * sizeof(char));
			if (new_good_node->goods_name == NULL)
			{
				printf("can not allocate memory");
				exit(0);
			}
			strcpy(new_good_node->goods_name, input[1]);
			new_good_node->goods_seller = (char*)malloc((strlen(input[3]) + 1) * sizeof(char));
			if (new_good_node->goods_seller == NULL)
			{
				printf("can not allocate memory");
				exit(0);
			}
			strcpy(new_good_node->goods_seller, input[3]);
			new_good_node->goods_owner = (char*)malloc((strlen(current_user_buyer->user_buyer_name) + 1) * sizeof(char));
			if (new_good_node->goods_owner == NULL)
			{
				printf("can not allocate memory");
				exit(0);
			}
			strcpy(new_good_node->goods_owner, current_user_buyer->user_buyer_name);/*chon in node baraye kalaye kharide shode hast  owner->kharidar->current_user_buyer*/
			new_good_node->goods_price = temp_gs->goods_price;
			new_good_node->goods_count = count_g;
			new_good_node->count_rater = 0;/*chon in node baraye kalaye kharide shode hast count_rater->buyer chand bar be in kala emtiyaz dade*/
			new_good_node->sum_rate = 0;/*chon in node baraye kalaye kharide shode hast sum_rate->buyer be in kala che emtiyaz dade*/
			struct goods* current_new;
			struct goods* preve_new;
			preve_new = head_goods_buyer;
			current_new = head_goods_buyer->next;
			while ((current_new != NULL) && (strcmp(current_new->goods_name, new_good_node->goods_name) < 0))/*add to head_goods buyer in order*/
			{
				preve_new = preve_new->next;
				current_new = current_new->next;
			}
			new_good_node->next = preve_new->next;
			preve_new->next = new_good_node;
			printf("YOU BOUGHT THE ITEM\n");
		}
	}


}
