void fbuy(struct buyer* current_user_buyer, struct seller* head_seller, struct goods* head_goods_seller, struct goods* head_goods_buyer, char** input);
/*dar soorate emkan amaliate kharid ra anjam midahad agar kala ba haman gheymat ghablan vojood dasht->tedad ra update va emkan rate be buyer
else->new node*/
