#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h" 
void fchange_price(struct goods* head_goods_seller, struct seller* current_seller_user, char** input)
{
	struct goods* current;
	current = head_goods_seller->next;
	while (current != NULL)
	{
		if ((strcmp(current->goods_seller, current_seller_user->user_seller_name) == 0) &&
			(strcmp(current->goods_name, input[1]) == 0))
		{
			break;
		}
		current = current->next;
	}
	if (current == NULL)
	{
		printf("NO MATCH FOUND\n");

	}
	else
	{
		current->goods_price = atoi(input[2]);
		printf("PRICE CHANGED\n");
	}

}