void fchange_price(struct goods* head_goods_seller, struct seller* current_seller_user, char** input);
/*chnges the price of the product*/