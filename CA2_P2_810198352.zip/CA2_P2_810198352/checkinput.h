char** fcheckinput(char** input, int count_words);
