#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
int fcheck_search(int search_input_holder, char** input)
{
	/*name->1  min_price->2  max_price->4   seller_username->8*/
	int remainder, check;/*0->repeated 1->name  2->min_price  4->max_price   8->seller_username*/
	if (strcmp(input[0], "name") == 0)
	{
		remainder = search_input_holder % 2;
		if (remainder > 0)
			check = 0;
		else
			check = 1;

	}
	else if (strcmp(input[0], "min_price") == 0)

	{
		remainder = search_input_holder % 4;
		if (remainder >= 2)
			check = 0;
		else
			check = 2;

	}
	else if (strcmp(input[0], "max_price") == 0)

	{
		remainder = search_input_holder % 8;
		if (remainder >= 4)
			check = 0;
		else
			check = 4;

	}
	else if (strcmp(input[0], "seller_username") == 0)

	{
		remainder = search_input_holder % 16;
		if (remainder >= 8)
			check = 0;
		else
			check = 8;

	}
	return check;

}