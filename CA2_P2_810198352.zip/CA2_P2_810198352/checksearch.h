int fcheck_search(int search_input_holder, char** input);
/*check mikonad good_attribute tekrari nabashad*/
