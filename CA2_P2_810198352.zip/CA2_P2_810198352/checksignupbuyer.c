#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h"
int fcheck_signup_buyer(struct seller* head_buyer, char** input)
{
	int check = 0;
	struct buyer* current;
	current = head_buyer->next;
	while (current != NULL)
	{
		if (strcmp(current->user_buyer_name, input[1]) == 0)
		{
			check++;
			break;
		}
		current = current->next;
	}
	return check;
}