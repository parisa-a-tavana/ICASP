int fcheck_signup_buyer(struct seller* head_buyer, char** input);
/*check mikonad buyer sharayet signup dashte bashad*/
