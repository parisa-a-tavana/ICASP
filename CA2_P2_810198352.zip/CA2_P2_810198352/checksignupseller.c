#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h"
int fcheck_signup_seller(struct seller* head_seller, char** input)
{
	int check = 0;
	struct seller* current;
	current = head_seller->next;
	while (current != NULL)
	{
		if (strcmp(current->user_seller_name, input[1]) == 0)
		{
			check++;
			break;
		}
		current = current->next;
	}
	return check;
}