int fcheck_signup_seller(struct seller* head_seller, char** input);
/*check mikonad ke seller sharayet sugnup dashte bashad*/