#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
int fcount_words(char*order)
{
	if ((strcmp(order, "signup") == 0) || (strcmp(order, "login") == 0) || (strcmp(order, "buy") == 0)
		|| (strcmp(order, "add_goods") == 0) || (strcmp(order, "rate_goods") == 0))
		return 4;
	if ((strcmp(order, "logout") == 0) || (strcmp(order, "view") == 0) || (strcmp(order, "show_goods") == 0) || (strcmp(order, "exit") == 0))
		return 1;

	if ((strcmp(order, "deposit") == 0) || (strcmp(order, "search") == 0) || (strcmp(order, "max_price") == 0)
		|| (strcmp(order, "min_price") == 0) || (strcmp(order, "name") == 0) || (strcmp(order, "seller_username") == 0))
		return 2;
	if (strcmp(order, "change_goods_price") == 0)
		return 3;
	
}