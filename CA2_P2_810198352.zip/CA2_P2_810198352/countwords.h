int fcount_words(char*order);
/*dar sharayeti ke input valid ast be in tabe avalin kalame input dade mishavad va dar khorooji->tedad kalamte vared karde */