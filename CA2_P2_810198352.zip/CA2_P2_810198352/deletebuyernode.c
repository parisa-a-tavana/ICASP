#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h" 
struct buyer* fdelete_buyer_node(struct buyer* head, struct buyer* delete_node)
{
	struct buyer* current;
	struct buyer* prev;
	prev = head;
	current = head->next;
	while (current != NULL)
	{
		if (strcmp(current->user_buyer_name, delete_node->user_buyer_name) == 0)
		{
			break;
		}
		prev = prev->next;
		current = current->next;
	}
	if (current != NULL)
	{
		prev->next = current->next;
		free(current);
	}
	struct goods* new_current;
	new_current = prev->next;
	return new_current;
}