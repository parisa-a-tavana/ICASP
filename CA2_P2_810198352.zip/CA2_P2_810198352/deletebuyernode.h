struct buyer* fdelete_buyer_node(struct buyer* head, struct buyer* delete_node);
/*yek buyer_node khas ra az list hazf */