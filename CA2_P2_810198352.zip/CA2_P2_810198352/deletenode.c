#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h" 
struct goods* fdelete_node(struct goods* head, struct goods* delete_node)
{
	struct goods* current;
	struct goods* prev;
	prev = head;
	current = head->next;
	while (current != NULL)
	{
		if (strcmp(current->goods_name, delete_node->goods_name) == 0)
		{
			break;
		}
		prev = prev->next;
		current = current->next;
	}
	if (current != NULL)
	{
		prev->next = current->next;
		free(current);
	}
	struct goods* new_current;
	new_current = prev->next;
	return new_current;

}