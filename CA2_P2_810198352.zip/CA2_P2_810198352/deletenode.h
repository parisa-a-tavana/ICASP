struct goods* fdelete_node(struct goods* head, struct goods* delete_node);
/*yek goods node khas ra az list delete mikonad*/