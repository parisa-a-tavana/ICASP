#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h" 
struct seller* fdelete_seller_node(struct seller* head, struct seller* delete_node)
{
	struct seller* current;
	struct seller* prev;
	prev = head;
	current = head->next;
	while (current != NULL)
	{
		if (strcmp(current->user_seller_name, delete_node->user_seller_name) == 0)
		{
			break;
		}
		prev = prev->next;
		current = current->next;
	}
	if (current != NULL)
	{
		prev->next = current->next;
		free(current);
	}
	struct goods* new_current;
	new_current = prev->next;
	return new_current;
}