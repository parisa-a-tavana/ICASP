struct seller* fdelete_seller_node(struct seller* head, struct seller* delete_node);
/*yek seller_node khas ra hazf az list*/