#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h"
#include"deletenode.h"
struct goods* fedit_search_list(char** input, struct goods* head_search)
{
	struct goods* current;
	current = head_search->next;
	if (strcmp(input[0], "name") == 0)
	{
		while (current != NULL)
			if (strcmp(current->goods_name, input[1]) != 0)/*bayad hazf shavad*/
			{
				current = fdelete_node(head_search, current);
			}
			else
			{
				current = current->next;
			}

	}
	else if (strcmp(input[0], "seller_username") == 0)
	{
		while (current != NULL)
			if (strcmp(current->goods_seller, input[1]) != 0)/*bayad hazf shavad*/
			{
				current = fdelete_node(head_search, current);
			}
			else
			{
				current = current->next;
			}

	}
	else if (strcmp(input[0], "min_price") == 0)
	{
		int min_price = atoi(input[1]);
		while (current != NULL)
			if ((current->goods_price)<(min_price))/*bayad hazf shavad*/
			{
				current = fdelete_node(head_search, current);
				int k = 50;
			}
			else
			{
				current = current->next;
			}

	}
	else if (strcmp(input[0], "max_price") == 0)
	{
		int max_price = atoi(input[1]);
		while (current != NULL)
			if ((current->goods_price)>(max_price))/*bayad hazf shavad*/
			{
				current = fdelete_node(head_search, current);

			}
			else
			{
				current = current->next;
			}

	}

	return head_search;
}