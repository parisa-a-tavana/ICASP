struct goods* fedit_search_list(char** input, struct goods* head_search);
/*search list ra bar asas goods_attribute haye 2 be bad edit ve namoshtarak ha ra delete*/