#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h"
#include"deletenode.h"
#include"deletebuyernode.h"
#include"deletesellernode.h"
void freee(struct goods* head_goods_buyer, struct goods* head_goods_seller, struct buyer* head_buyer, struct seller* head_seller)
{
	struct goods* current;
	current = head_goods_buyer->next;
	while (current != NULL)
	{
		current = fdelete_node(head_goods_buyer, current);
	}
	current = head_goods_seller->next;
	while (current != NULL)
	{
		current = fdelete_node(head_goods_seller, current);
	}
	struct buyer* current_b;
	current_b = head_buyer->next;
	while (current_b != NULL)
	{
		current_b = fdelete_buyer_node(head_buyer, current_b);
	}
	struct seller* current_s;
	current_s = head_seller->next;
	while (current_s != NULL)
	{
		current_s = fdelete_seller_node(head_seller, current_s);
	}


}
