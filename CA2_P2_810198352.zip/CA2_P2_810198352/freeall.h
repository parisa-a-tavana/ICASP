void freee(struct goods* head_goods_buyer, struct goods* head_goods_seller, struct buyer* head_buyer, struct seller* head_seller);
/*dar payane barnme 4 list ra free mikonad*/
