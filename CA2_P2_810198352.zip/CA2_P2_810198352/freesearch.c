#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h"
#include"deletenode.h"
struct goods* ffree_search_list(struct goods* head_search)
{
	struct goods* current;
	current = head_search->next;
	while (current != NULL)
	{
		current = fdelete_node(head_search, current);
	}
	return head_search;
}