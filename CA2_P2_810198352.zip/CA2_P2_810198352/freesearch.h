struct goods* ffree_search_list(struct goods* head_search);
/*pas az neshan dadan natije ->list ra free*/