char** fgetinput();

