#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h"
struct buyer* flogin_buyer(struct buyer* head_buyer, char** input)
{
	struct buyer* current;
	current = head_buyer->next;
	while (current != NULL)
	{
		if ((strcmp(current->user_buyer_name, input[1]) == 0) && (strcmp(input[2], current->user_buyer_password) == 0))
			break;
		else
			current = current->next;
	}
	return current;
}