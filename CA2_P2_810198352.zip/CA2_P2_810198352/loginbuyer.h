struct buyer* flogin_buyer(struct buyer* head_buyer, char** input);
/*check mikonad seller mitavanad login konad ya na yes->node user->output no->null->output */