struct seller* flogin_seller(struct seller* head_seller, char** input);
/*check mikonad seller mitavanad login konad ya na yes->node user->output no->null->output */
