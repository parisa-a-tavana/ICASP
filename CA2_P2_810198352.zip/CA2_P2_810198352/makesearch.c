#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h" 
#include"addsearchnode.h"
struct goods* fmake_search_list(char** input, struct goods* head_goods_seller, struct goods* head_search)
{
	struct goods* search_goods_seller_list;
	search_goods_seller_list = head_goods_seller->next;
	float ave;
	if (strcmp(input[0], "name") == 0)
	{
		while (search_goods_seller_list != NULL)
		{
			if (strcmp(search_goods_seller_list->goods_name, input[1]) == 0)/*agar kalaye dar list vejegi ra dasht ->make a new node*/
			{
				if (search_goods_seller_list->count_rater < 5)/*kala ba vijhegi search*/
				{
					struct goods* new_search_node = (struct goods*)malloc(sizeof(struct goods));/*ye new node ba haman vijhegi haye search_goods_seller_list*/
					if (new_search_node == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					new_search_node->goods_name = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_name) + 1));
					if (new_search_node->goods_name == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_search_node->goods_name, search_goods_seller_list->goods_name);
					new_search_node->goods_seller = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_seller) + 1));
					if (new_search_node->goods_seller == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_search_node->goods_seller, search_goods_seller_list->goods_seller);
					new_search_node->goods_owner = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_owner) + 1));
					if (new_search_node->goods_owner == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_search_node->goods_owner, search_goods_seller_list->goods_owner);
					new_search_node->count_rater = search_goods_seller_list->count_rater;
					new_search_node->goods_count = search_goods_seller_list->goods_count;
					new_search_node->goods_price = search_goods_seller_list->goods_price;
					new_search_node->sum_rate = search_goods_seller_list->sum_rate;
					new_search_node->next = NULL;
					/*node ra sakhtim hal bayad dar list bezarim*/
					head_search = fadd_search_node(head_search, new_search_node);




				}
				else
				{
					ave = search_goods_seller_list->sum_rate / search_goods_seller_list->count_rater;
					if (ave >= 2)/*kala ba vijhegi search*/
					{
						struct goods* new_search_node = (struct goods*)malloc(sizeof(struct goods));/*ye new node ba haman vijhegi haye search_goods_seller_list*/
						if (new_search_node == NULL)
						{
							printf("can not allocate memory");
							exit(0);
						}
						new_search_node->goods_name = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_name) + 1));
						if (new_search_node->goods_name == NULL)
						{
							printf("can not allocate memory");
							exit(0);
						}
						strcpy(new_search_node->goods_name, search_goods_seller_list->goods_name);
						new_search_node->goods_seller = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_seller) + 1));
						if (new_search_node->goods_seller == NULL)
						{
							printf("can not allocate memory");
							exit(0);
						}
						strcpy(new_search_node->goods_seller, search_goods_seller_list->goods_seller);
						new_search_node->goods_owner = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_owner) + 1));
						if (new_search_node->goods_owner == NULL)
						{
							printf("can not allocate memory");
							exit(0);
						}
						strcpy(new_search_node->goods_owner, search_goods_seller_list->goods_owner);
						new_search_node->count_rater = search_goods_seller_list->count_rater;
						new_search_node->goods_count = search_goods_seller_list->goods_count;
						new_search_node->goods_price = search_goods_seller_list->goods_price;
						new_search_node->sum_rate = search_goods_seller_list->sum_rate;
						new_search_node->next = NULL;
						/*node ra sakhtim hal bayad dar list bezarim*/
						head_search = fadd_search_node(head_search, new_search_node);
					}
				}
			}
			search_goods_seller_list = search_goods_seller_list->next;
		}
	}
	else if (strcmp(input[0], "seller_username") == 0)

	{
		while (search_goods_seller_list != NULL)
		{
			if (strcmp(search_goods_seller_list->goods_seller, input[1]) == 0)/*agar kalaye dar list vejegi ra dasht ->make a new node*/
			{
				if (search_goods_seller_list->count_rater < 5)/*kala ba vijhegi search*/
				{
					struct goods* new_search_node = (struct goods*)malloc(sizeof(struct goods));/*ye new node ba haman vijhegi haye search_goods_seller_list*/
					if (new_search_node == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					new_search_node->goods_name = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_name) + 1));
					if (new_search_node->goods_name == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_search_node->goods_name, search_goods_seller_list->goods_name);
					new_search_node->goods_seller = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_seller) + 1));
					if (new_search_node->goods_seller == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_search_node->goods_seller, search_goods_seller_list->goods_seller);
					new_search_node->goods_owner = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_owner) + 1));
					if (new_search_node->goods_owner == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_search_node->goods_owner, search_goods_seller_list->goods_owner);
					new_search_node->count_rater = search_goods_seller_list->count_rater;
					new_search_node->goods_count = search_goods_seller_list->goods_count;
					new_search_node->goods_price = search_goods_seller_list->goods_price;
					new_search_node->sum_rate = search_goods_seller_list->sum_rate;
					new_search_node->next = NULL;
					/*node ra sakhtim hal bayad dar list bezarim*/
					head_search = fadd_search_node(head_search, new_search_node);
				}
				else
				{
					ave = search_goods_seller_list->sum_rate / search_goods_seller_list->count_rater;
					if (ave >= 2)/*kala ba vijhegi search*/
					{
						struct goods* new_search_node = (struct goods*)malloc(sizeof(struct goods));/*ye new node ba haman vijhegi haye search_goods_seller_list*/
						if (new_search_node == NULL)
						{
							printf("can not allocate memory");
							exit(0);
						}
						new_search_node->goods_name = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_name) + 1));
						if (new_search_node->goods_name == NULL)
						{
							printf("can not allocate memory");
							exit(0);
						}
						strcpy(new_search_node->goods_name, search_goods_seller_list->goods_name);
						new_search_node->goods_seller = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_seller) + 1));
						if (new_search_node->goods_seller == NULL)
						{
							printf("can not allocate memory");
							exit(0);
						}
						strcpy(new_search_node->goods_seller, search_goods_seller_list->goods_seller);
						new_search_node->goods_owner = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_owner) + 1));
						if (new_search_node->goods_owner == NULL)
						{
							printf("can not allocate memory");
							exit(0);
						}
						strcpy(new_search_node->goods_owner, search_goods_seller_list->goods_owner);
						new_search_node->count_rater = search_goods_seller_list->count_rater;
						new_search_node->goods_count = search_goods_seller_list->goods_count;
						new_search_node->goods_price = search_goods_seller_list->goods_price;
						new_search_node->sum_rate = search_goods_seller_list->sum_rate;
						new_search_node->next = NULL;
						/*node ra sakhtim hal bayad dar list bezarim*/
						head_search = fadd_search_node(head_search, new_search_node);
					}
				}
			}
			search_goods_seller_list = search_goods_seller_list->next;
		}
	}
	else if (strcmp(input[0], "max_price") == 0)

	{
		int max_price;
		max_price = atoi(input[1]);
		while (search_goods_seller_list != NULL)
		{
			if (search_goods_seller_list->goods_price <= max_price)/*agar kalaye dar list vejegi ra dasht ->make a new node*/
			{
				if (search_goods_seller_list->count_rater < 5)/*kala ba vijhegi search*/
				{
					struct goods* new_search_node = (struct goods*)malloc(sizeof(struct goods));/*ye new node ba haman vijhegi haye search_goods_seller_list*/
					if (new_search_node == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					new_search_node->goods_name = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_name) + 1));
					if (new_search_node->goods_name == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_search_node->goods_name, search_goods_seller_list->goods_name);
					new_search_node->goods_seller = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_seller) + 1));
					if (new_search_node->goods_seller == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_search_node->goods_seller, search_goods_seller_list->goods_seller);
					new_search_node->goods_owner = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_owner) + 1));
					if (new_search_node->goods_owner == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_search_node->goods_owner, search_goods_seller_list->goods_owner);
					new_search_node->count_rater = search_goods_seller_list->count_rater;
					new_search_node->goods_count = search_goods_seller_list->goods_count;
					new_search_node->goods_price = search_goods_seller_list->goods_price;
					new_search_node->sum_rate = search_goods_seller_list->sum_rate;
					new_search_node->next = NULL;
					/*node ra sakhtim hal bayad dar list bezarim*/
					head_search = fadd_search_node(head_search, new_search_node);
				}
				else
				{
					ave = search_goods_seller_list->sum_rate / search_goods_seller_list->count_rater;
					if (ave >= 2)/*kala ba vijhegi search*/
					{
						struct goods* new_search_node = (struct goods*)malloc(sizeof(struct goods));/*ye new node ba haman vijhegi haye search_goods_seller_list*/
						if (new_search_node == NULL)
						{
							printf("can not allocate memory");
							exit(0);
						}
						new_search_node->goods_name = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_name) + 1));
						if (new_search_node->goods_name == NULL)
						{
							printf("can not allocate memory");
							exit(0);
						}
						strcpy(new_search_node->goods_name, search_goods_seller_list->goods_name);
						new_search_node->goods_seller = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_seller) + 1));
						if (new_search_node->goods_seller == NULL)
						{
							printf("can not allocate memory");
							exit(0);
						}
						strcpy(new_search_node->goods_seller, search_goods_seller_list->goods_seller);
						new_search_node->goods_owner = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_owner) + 1));
						if (new_search_node->goods_owner == NULL)
						{
							printf("can not allocate memory");
							exit(0);
						}
						strcpy(new_search_node->goods_owner, search_goods_seller_list->goods_owner);
						new_search_node->count_rater = search_goods_seller_list->count_rater;
						new_search_node->goods_count = search_goods_seller_list->goods_count;
						new_search_node->goods_price = search_goods_seller_list->goods_price;
						new_search_node->sum_rate = search_goods_seller_list->sum_rate;
						new_search_node->next = NULL;
						/*node ra sakhtim hal bayad dar list bezarim*/
						head_search = fadd_search_node(head_search, new_search_node);
					}
				}
			}
			search_goods_seller_list = search_goods_seller_list->next;
		}
	}
	else if (strcmp(input[0], "min_price") == 0)

	{
		int min_price;
		min_price = atoi(input[1]);
		while (search_goods_seller_list != NULL)
		{
			if (search_goods_seller_list->goods_price >= min_price)/*agar kalaye dar list vejegi ra dasht ->make a new node*/
			{
				if (search_goods_seller_list->count_rater < 5)/*kala ba vijhegi search*/
				{
					struct goods* new_search_node = (struct goods*)malloc(sizeof(struct goods));/*ye new node ba haman vijhegi haye search_goods_seller_list*/
					if (new_search_node == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					new_search_node->goods_name = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_name) + 1));
					if (new_search_node->goods_name == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_search_node->goods_name, search_goods_seller_list->goods_name);
					new_search_node->goods_seller = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_seller) + 1));
					if (new_search_node->goods_seller == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_search_node->goods_seller, search_goods_seller_list->goods_seller);
					new_search_node->goods_owner = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_owner) + 1));
					if (new_search_node->goods_owner == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_search_node->goods_owner, search_goods_seller_list->goods_owner);
					new_search_node->count_rater = search_goods_seller_list->count_rater;
					new_search_node->goods_count = search_goods_seller_list->goods_count;
					new_search_node->goods_price = search_goods_seller_list->goods_price;
					new_search_node->sum_rate = search_goods_seller_list->sum_rate;
					new_search_node->next = NULL;
					/*node ra sakhtim hal bayad dar list bezarim*/
					head_search = fadd_search_node(head_search, new_search_node);
				}
				else
				{
					ave = search_goods_seller_list->sum_rate / search_goods_seller_list->count_rater;
					if (ave >= 2)/*kala ba vijhegi search*/
					{
						struct goods* new_search_node = (struct goods*)malloc(sizeof(struct goods));/*ye new node ba haman vijhegi haye search_goods_seller_list*/
						if (new_search_node == NULL)
						{
							printf("can not allocate memory");
							exit(0);
						}
						new_search_node->goods_name = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_name) + 1));
						if (new_search_node->goods_name == NULL)
						{
							printf("can not allocate memory");
							exit(0);
						}
						strcpy(new_search_node->goods_name, search_goods_seller_list->goods_name);
						new_search_node->goods_seller = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_seller) + 1));
						if (new_search_node->goods_seller == NULL)
						{
							printf("can not allocate memory");
							exit(0);
						}
						strcpy(new_search_node->goods_seller, search_goods_seller_list->goods_seller);
						new_search_node->goods_owner = (char*)malloc(sizeof(char)*(strlen(search_goods_seller_list->goods_owner) + 1));
						if (new_search_node->goods_owner == NULL)
						{
							printf("can not allocate memory");
							exit(0);
						}
						strcpy(new_search_node->goods_owner, search_goods_seller_list->goods_owner);
						new_search_node->count_rater = search_goods_seller_list->count_rater;
						new_search_node->goods_count = search_goods_seller_list->goods_count;
						new_search_node->goods_price = search_goods_seller_list->goods_price;
						new_search_node->sum_rate = search_goods_seller_list->sum_rate;
						new_search_node->next = NULL;
						/*node ra sakhtim hal bayad dar list bezarim*/
						head_search = fadd_search_node(head_search, new_search_node);
					}
				}
			}
			search_goods_seller_list = search_goods_seller_list->next;
		}
	}


	return head_search;
}