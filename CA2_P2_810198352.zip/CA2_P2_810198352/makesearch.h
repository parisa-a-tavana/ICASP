struct goods* fmake_search_list(char** input, struct goods* head_goods_seller, struct goods* head_search);
/*bar asas avalin goods_attribute search list misazad*/
