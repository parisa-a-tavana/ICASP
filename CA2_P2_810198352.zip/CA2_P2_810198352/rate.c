#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h" 
void frate(struct goods* head_goods_seller, struct goods* head_goods_buyer, struct buyer* current_buyer_user, char** input)
{

	int check = 0;/*-1->rating error*/
	struct goods* temp_s;/*matched product in seller */
	temp_s = head_goods_seller->next;
	int rate = atoi(input[3]);
	while (temp_s != NULL)
	{
		if ((strcmp(temp_s->goods_name, input[1]) == 0) && (strcmp(temp_s->goods_seller, input[2]) == 0))/*agar kala ba name va seller
																										 /*dar goods_seller ba goods_name & seller_name->kala yekta																								 baraye foroosh bashad*/
		{
			break;
		}
		temp_s = temp_s->next;
	}
	if (temp_s == NULL)
	{
		printf("NO PRODUCT FOUND TO BE RATED\n");
	}
	else
	{
		struct goods* temp_b;/*matched product in buyer*/
		temp_b = head_goods_buyer->next;
		while (temp_b != NULL)
		{
			if ((strcmp(temp_b->goods_name, input[1]) == 0) && (strcmp(current_buyer_user->user_buyer_name, temp_b->goods_owner) == 0)
				&& (strcmp(temp_b->goods_seller, input[2]) == 0))/*name va seller temp_s ba input yeki owner ham ba user yeki*/

			{
				break;
			}
			temp_b = temp_b->next;
		}
		if (temp_b == NULL)
		{
			printf("YOU HAVE NOT BOUGHT SUCH PRODUCT\n");
		}
		else
		{
			if (temp_b->count_rater != 0)
			{
				temp_b = head_goods_buyer->next;
				while (temp_b != NULL)
				{
					if ((strcmp(temp_b->goods_name, input[1]) == 0) && (strcmp(current_buyer_user->user_buyer_name, temp_b->goods_owner) == 0)
						&& (strcmp(temp_b->goods_seller, input[2]) == 0) && (temp_b->count_rater == 0))/*halati ke kala ra ba bish az 1 gheymat kharide bashad
																									   vali hame ra rate nakarde(be ezaye har amaliat buy mitavan rate kard)*/
					{
						break;
					}
					temp_b = temp_b->next;
				}
				if (temp_b == NULL)
				{
					printf("YOU HAVE ALREADY RATED THIS PRODUCT\n");
				}
				else
				{

					if ((rate >= 1) && (rate <= 5))
					{
						temp_b->count_rater++;/*kalaye buyer rate shod */
						temp_b->sum_rate = rate;
						temp_s->count_rater++;/*yek nafar be rater haye in kalye baraye hale foroosh ezafe shod*/
						temp_s->sum_rate += rate;/*rate be sum_rate kalaye baraye foroosh ezafe shod*/
						printf("YOU RATED THE PRODUCT\n");

					}
					else
					{
						printf("INVALID RANK\n");
					}
				}
			}
			else
			{

				if ((rate >= 1) && (rate <= 5))
				{
					temp_b->count_rater++;/*kalaye buyer rate shod */
					temp_b->sum_rate = rate;
					temp_s->count_rater++;/*yek nafar be rater haye in kalye baraye hale foroosh ezafe shod*/
					temp_s->sum_rate += rate;/*rate be sum_rate kalaye baraye foroosh ezafe shod*/
					printf("YOU RATED THE PRODUCT\n");

				}
				else
				{
					printf("INVALID RANK\n");
				}
			}

		}

	}


}