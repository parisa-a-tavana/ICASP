void frate(struct goods* head_goods_seller, struct goods* head_goods_buyer, struct buyer* current_buyer_user, char** input);
/*kala ra agar sharayet ra dashte bashad rate mikonad*/