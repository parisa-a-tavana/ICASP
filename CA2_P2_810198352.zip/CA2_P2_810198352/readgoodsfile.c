#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h"
void fread_file_goods(FILE* goods, struct goods* head_goods_seller, struct goods* head_goods_buyer)
{
	char x;
	int i, j, k;
	int length;/*baraye khandane file*/
	struct goods* preve_g;/*baraye search dar  list*/
	struct goods* current_g;/*baraye search dar  list*/
	x = getc(goods);
	while (x != EOF)
	{
		char* line = (char*)malloc(sizeof(char));
		i = 0;
		while (1)
		{
			if (x != '\n')
			{
				line[i] = x;
				i++;
				line = (char*)realloc(line, (i + 1) * sizeof(char));
				x = fgetc(goods);
			}
			else
			{
				line[i] = '\0';
				length = i;
				char** word = (char**)malloc(8 * sizeof(char*));/*dar har khat 8 kalame*/
				for (i = 0; i < 8; i++)
				{
					word[i] = (char*)malloc(sizeof(char));
				}
				i = 0; j = 0;
				for (k = 0; k < length; k++)
				{
					if (line[k] != ' ')
					{
						j++;
						word[i] = (char*)realloc(word[i], (j + 10) * sizeof(char));
						if (word[i] == NULL) {
							printf("can not allocate memory\n");
							exit(0);
						}
						word[i][j - 1] = line[k];
					}
					else if (line[k] == ' ')
					{
						word[i][j] = '\0';
						j = 0;
						i++;
					}
				}
				word[i][j] = '\0';/*word0->is it "for_sale" or "sold" word1->owner word2->name word3->seller_name
								  word4->price word5->count word6->sum_rate word7->count_rater*/

				if (strcmp(word[0], "for_sale") == 0)
				{
					struct goods* new_for_sale_good_node = (struct goods*)malloc(sizeof(struct goods));
					if (new_for_sale_good_node == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					new_for_sale_good_node->goods_owner = (char*)malloc(sizeof(strlen(word[1]) + 1));
					if (new_for_sale_good_node->goods_owner == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_for_sale_good_node->goods_owner, word[1]);
					new_for_sale_good_node->goods_name = (char*)malloc(sizeof(strlen(word[2]) + 1));
					if (new_for_sale_good_node->goods_name == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_for_sale_good_node->goods_name, word[2]);
					new_for_sale_good_node->goods_seller = (char*)malloc(sizeof(strlen(word[3]) + 1));
					if (new_for_sale_good_node->goods_seller == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_for_sale_good_node->goods_seller, word[3]);
					new_for_sale_good_node->goods_price = atoi(word[4]);
					new_for_sale_good_node->goods_count = atoi(word[5]);
					new_for_sale_good_node->sum_rate = atoi(word[6]);
					new_for_sale_good_node->count_rater = atoi(word[7]);
					preve_g = head_goods_seller;
					current_g = head_goods_seller->next;
					while ((current_g != NULL) && (strcmp(current_g->goods_name, new_for_sale_good_node->goods_name) < 0))
					{
						preve_g = preve_g->next;
						current_g = current_g->next;
					}
					new_for_sale_good_node->next = preve_g->next;
					preve_g->next = new_for_sale_good_node;

				}
				if (strcmp(word[0], "sold") == 0)
				{
					struct goods* new_sold_good_node = (struct goods*)malloc(sizeof(struct goods));
					if (new_sold_good_node == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					new_sold_good_node->goods_owner = (char*)malloc(sizeof(strlen(word[1]) + 1));
					if (new_sold_good_node->goods_owner == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_sold_good_node->goods_owner, word[1]);
					new_sold_good_node->goods_name = (char*)malloc(sizeof(strlen(word[2]) + 1));
					if (new_sold_good_node->goods_name == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_sold_good_node->goods_name, word[2]);
					new_sold_good_node->goods_seller = (char*)malloc(sizeof(strlen(word[3]) + 1));
					if (new_sold_good_node->goods_seller == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_sold_good_node->goods_seller, word[3]);
					new_sold_good_node->goods_price = atoi(word[4]);
					new_sold_good_node->goods_count = atoi(word[5]);
					new_sold_good_node->sum_rate = atoi(word[6]);
					new_sold_good_node->count_rater = atoi(word[7]);
					preve_g = head_goods_buyer;
					current_g = head_goods_buyer->next;
					while ((current_g != NULL) && (strcmp(current_g->goods_name, new_sold_good_node->goods_name) < 0))
					{
						preve_g = preve_g->next;
						current_g = current_g->next;
					}
					new_sold_good_node->next = preve_g->next;
					preve_g->next = new_sold_good_node;
				}
				int saaadjhn;
				for (i = 0; i < 8; i++)
					free(word[i]);
				free(word);
				free(line);
				x = getc(goods);
				break;
			}

		}
	}
}