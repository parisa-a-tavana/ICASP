#include <stdlib.h>
#include <stdio.h> 
void fread_file_goods(FILE* goods, struct goods* head_goods_seller, struct goods* head_goods_buyer);
/*reads goods info from file*/