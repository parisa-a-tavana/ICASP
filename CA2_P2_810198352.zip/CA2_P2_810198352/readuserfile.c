#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h"
void fread_file_usere(FILE* user, struct seller* head_seller, struct buyer* head_buyer)
{
	char x;
	int i, j, k;
	int length;/*baraye khandane file*/
	struct seller* preve_s;/*baraye search dar list s->seller*/
	struct seller* current_s;/*baraye search dar list s->seller*/
	struct buyer* preve_b;/*baraye search dar list b->buyer*/
	struct buyer* current_b;/*baraye search dar list b->buyer*/
	x = getc(user);
	while (x != EOF)
	{
		char* line = (char*)malloc(sizeof(char));
		i = 0;
		while (1)
		{
			if (x != '\n')
			{
				line[i] = x;
				i++;
				line = (char*)realloc(line, (i + 1) * sizeof(char));
				x = fgetc(user);
			}
			else
			{
				line[i] = '\0';
				length = i;
				char** word = (char**)malloc(4 * sizeof(char*));/*dar har khat 4 kalame*/
				for (i = 0; i < 4; i++)
				{
					word[i] = (char*)malloc(sizeof(char));
				}
				i = 0; j = 0;
				for (k = 0; k < length; k++)
				{
					if (line[k] != ' ')
					{
						j++;
						word[i] = (char*)realloc(word[i], (j + 10) * sizeof(char));
						if (word[i] == NULL) {
							printf("can not allocate memory\n");
							exit(0);
						}
						word[i][j - 1] = line[k];
					}
					else if (line[k] == ' ')
					{
						word[i][j] = '\0';;/*word0->roll word1->name word2->password word3->amount of money*/
						j = 0;
						i++;
					}
				}
				word[i][j] = '\0';
				if (strcmp(word[0], "seller") == 0)
				{
					struct seller* new_seller_node = (struct seller*)malloc(sizeof(struct seller));
					if (new_seller_node == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					new_seller_node->user_seller_accountmoney = atoi(word[3]);
					new_seller_node->user_seller_role = (char*)malloc((strlen(word[0]) + 1) * sizeof(char));
					if (new_seller_node->user_seller_role == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_seller_node->user_seller_role, word[0]);
					new_seller_node->user_seller_name = (char*)malloc((strlen(word[1]) + 1) * sizeof(char));
					if (new_seller_node->user_seller_name == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_seller_node->user_seller_name, word[1]);
					new_seller_node->user_seller_password = (char*)malloc((strlen(word[2]) + 1) * sizeof(char));
					if (new_seller_node->user_seller_password == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_seller_node->user_seller_password, word[2]);
					preve_s = head_seller;
					current_s = head_seller->next;
					while ((current_s != NULL) && (strcmp(current_s->user_seller_name, new_seller_node->user_seller_name) < 0))
					{
						preve_s = preve_s->next;
						current_s = current_s->next;
					}
					new_seller_node->next = preve_s->next;
					preve_s->next = new_seller_node;

				}
				if (strcmp(word[0], "buyer") == 0)
				{
					struct buyer* new_buyer_node = (struct buyer*)malloc(sizeof(struct buyer));
					if (new_buyer_node == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					new_buyer_node->user_buyer_accountmoney = atoi(word[3]);
					new_buyer_node->user_buyer_role = (char*)malloc((strlen(word[0]) + 1) * sizeof(char));
					if (new_buyer_node->user_buyer_role == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_buyer_node->user_buyer_role, word[0]);
					new_buyer_node->user_buyer_name = (char*)malloc((strlen(word[1]) + 1) * sizeof(char));
					if (new_buyer_node->user_buyer_name == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_buyer_node->user_buyer_name, word[1]);
					new_buyer_node->user_buyer_password = (char*)malloc((strlen(word[2]) + 1) * sizeof(char));
					if (new_buyer_node->user_buyer_password == NULL)
					{
						printf("can not allocate memory");
						exit(0);
					}
					strcpy(new_buyer_node->user_buyer_password, word[2]);
					preve_b = head_buyer;
					current_b = head_buyer->next;
					while ((current_b != NULL) && (strcmp(current_b->user_buyer_name, new_buyer_node->user_buyer_name) < 0))
					{
						preve_b = preve_b->next;
						current_b = current_b->next;
					}
					new_buyer_node->next = preve_b->next;
					preve_b->next = new_buyer_node;

				}
				int gkgv;
				for (i = 0; i < 4; i++)
					free(word[i]);
				free(word);
				free(line);
				x = getc(user);
				break;
			}
		}

	}
}