#include <stdlib.h>
#include <stdio.h> 
void fread_file_usere(FILE* user, struct seller* head_seller, struct buyer* head_buyer);
/*reads user info from file*/