#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h" 
struct goods* fremove_goods(struct goods* head_goods_seller, struct seller* current_seller_user, char** input)
{
	struct goods* temp;
	temp = head_goods_seller->next;
	struct goods* preve_temp;
	preve_temp = head_goods_seller;
	while (temp != NULL)
	{
		if ((strcmp(temp->goods_name, input[1]) == 0) && (strcmp(temp->goods_seller, current_seller_user->user_seller_name) == 0))/*if name and seller
																																  matches input and current_user name*/
		{
			break;
		}
		temp = temp->next;
		preve_temp = preve_temp->next;
	}
	if (temp == NULL)
		printf("NO MATCH FOUND \n");
	else
	{

		preve_temp->next = temp->next;
		free(temp);
		printf("PRODUCT GOT REMOVED\n");
	}
	return head_goods_seller;
}