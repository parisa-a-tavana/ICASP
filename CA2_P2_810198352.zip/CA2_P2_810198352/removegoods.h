struct goods* fremove_goods(struct goods* head_goods_seller, struct seller* current_seller_user, char** input);
/*kala ra az list kharej va free*/