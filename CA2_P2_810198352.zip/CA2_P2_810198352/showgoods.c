#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h" 
void fshow_goods(struct goods* head_goods_seller)
{
	struct goods* temp;
	temp = head_goods_seller->next;
	float ave;
	float rate;
	while (temp != NULL)
	{
		if (temp->count_rater >= 5)
		{
			ave = temp->sum_rate / temp->count_rater;
			if (ave >= 2)
			{
				printf("product name : %s \t seller name : %s \t price : %d \t number of products : %d \t average rate : %.2f \n",
					temp->goods_name, temp->goods_seller, temp->goods_price, temp->goods_count, ave);
			}

		}
		else if (temp->count_rater == 0)
		{
			printf("product name : %s \t seller name : %s \t price : %d \t number of products : %d \t average rate : 0 (not rated yet)\n",
				temp->goods_name, temp->goods_seller, temp->goods_price, temp->goods_count);
		}
		else
		{
			rate = temp->sum_rate;
			ave = rate / temp->count_rater;
			printf("product name : %s \t seller name : %s \t price = %d \t number of products : %d \t average rate : %.2f \n",
				temp->goods_name, temp->goods_seller, temp->goods_price, temp->goods_count, ave);
		}
		temp = temp->next;

	}
	printf("---------\n");
}
