void fshow_goods(struct goods* head_goods_seller);
/*tamame kala haye tamam for_sale ba rate kafi  ra print*/
