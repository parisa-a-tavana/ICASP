#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h" 
void fshow_search_result(struct goods* head_search)
{
	struct goods* current;
	current = head_search->next;
	int num = 0;
	float ave;
	float rate;
	while (current != NULL)
	{
		num++;
		if (current->count_rater >= 5)
		{
			rate = current->sum_rate;
			ave = rate / current->count_rater;
			if (ave >= 2)
				printf("product name: %s \t seller name : %s \t price : %d \t number of products : %d \t  averrage rate : %.2f \n",
					current->goods_name, current->goods_seller, current->goods_price, current->goods_count, ave);
			else
				num--;
		}
		else if (current->count_rater == 0)
		{

			printf("product name: %s \t seller name : %s \t price : \t number of products : %d \t  averrage rate : 0 (not rated yet) \n",
				current->goods_name, current->goods_seller, current->goods_price, current->goods_count);
		}
		else
		{
			rate = current->sum_rate;
			ave = rate / current->count_rater;
			printf("product name: %s \t seller name : %s \t price : %d \t number of products : %d \t  averrage rate : %.2f \n",
				current->goods_name, current->goods_seller, current->goods_price, current->goods_count, ave);
		}
		current = current->next;
	}
	if (num == 0)
		printf("NO MATCH FOUND\n");
	else
		printf("------------\n");

}