void fshow_search_result(struct goods* head_search);
/*tamae kalahayi ke motabegh search ba rate kafi ra print*/