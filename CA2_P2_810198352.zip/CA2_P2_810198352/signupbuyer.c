#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h"
void fsignup_buyer(struct buyer* head_buyer, char**input)
{
	struct buyer* preve_b;/*baraye search dar list b->buyer*/
	struct buyer* current_b;/*baraye search dar list b->buyer*/
	struct buyer* new_buyer_node = (struct buyer*)malloc(sizeof(struct buyer));
	if (new_buyer_node == NULL)
	{
		printf("can not allocate memory");
		exit(0);
	}
	new_buyer_node->user_buyer_name = (char*)malloc(sizeof(char)*(strlen(input[1]) + 1));
	if (new_buyer_node->user_buyer_name == NULL)
	{
		printf("can not allocate memory");
		exit(0);
	}
	strcpy(new_buyer_node->user_buyer_name, input[1]);
	new_buyer_node->user_buyer_password = (char*)malloc(sizeof(char)*(strlen(input[2]) + 1));
	if (new_buyer_node->user_buyer_password == NULL)
	{
		printf("can not allocate memory");
		exit(0);
	}
	strcpy(new_buyer_node->user_buyer_password, input[2]);
	new_buyer_node->user_buyer_role = (char*)malloc(sizeof(char)*(strlen(input[3]) + 1));
	if (new_buyer_node->user_buyer_role == NULL)
	{
		printf("can not allocate memory");
		exit(0);
	}
	strcpy(new_buyer_node->user_buyer_role, input[3]);
	new_buyer_node->user_buyer_accountmoney = 0;
	preve_b = head_buyer;
	current_b = head_buyer->next;
	while ((current_b != NULL) && (strcmp(current_b->user_buyer_name, new_buyer_node->user_buyer_name) < 0))
	{
		preve_b = preve_b->next;
		current_b = current_b->next;
	}
	new_buyer_node->next = preve_b->next;
	preve_b->next = new_buyer_node;
	printf("YOU SIGNED UP\n");
}