void fsignup_buyer(struct buyer* head_buyer, char**input);
/*buyer ra be list ezafe va signup mikonad*/