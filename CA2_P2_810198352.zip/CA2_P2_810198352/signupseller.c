#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h"
void fsignup_seller(struct seller* head_seller, char** input)
{
	struct seller* preve_s;/*baraye search dar list s->seller*/
	struct seller* current_s;/*baraye search dar list s->seller*/
	struct seller* new_seller_node = (struct seller*)malloc(sizeof(struct seller));
	if (new_seller_node == NULL)
	{
		printf("can not allocate memory");
		exit(0);
	}
	new_seller_node->user_seller_name = (char*)malloc(sizeof(char)*(strlen(input[1]) + 1));
	if (new_seller_node->user_seller_name == NULL)
	{
		printf("can not allocate memory");
		exit(0);
	}
	strcpy(new_seller_node->user_seller_name, input[1]);
	new_seller_node->user_seller_password = (char*)malloc(sizeof(char)*(strlen(input[2]) + 1));
	if (new_seller_node->user_seller_password == NULL)
	{
		printf("can not allocate memory");
		exit(0);
	}
	strcpy(new_seller_node->user_seller_password, input[2]);
	new_seller_node->user_seller_role = (char*)malloc(sizeof(char)*(strlen(input[3]) + 1));
	if (new_seller_node->user_seller_role == NULL)
	{
		printf("can not allocate memory");
		exit(0);
	}
	strcpy(new_seller_node->user_seller_role, input[3]);
	new_seller_node->user_seller_accountmoney = 0;
	preve_s = head_seller;
	current_s = head_seller->next;
	while ((current_s != NULL) && (strcmp(current_s->user_seller_name, new_seller_node->user_seller_name) < 0))
	{
		preve_s = preve_s->next;
		current_s = current_s->next;
	}
	new_seller_node->next = preve_s->next;
	preve_s->next = new_seller_node;
	printf("YOU SIGNED UP\n");
}