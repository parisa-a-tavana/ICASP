void fsignup_seller(struct seller* head_seller, char** input);
/*seller ra be list ezafe va signup mikonad*/
