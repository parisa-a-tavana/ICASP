struct goods {
	char*goods_seller;
	char*goods_name;
	int goods_price;
	int goods_count;
	int sum_rate;/*agar kala dar head_goods_seller(list kalahaye for_sale)-> kharidar ha dar kol che emtiazi
				 agar dar head_goods_buyer->owner che emtiazi dade*/
	int count_rater;/*agar kala dar head_goods_seller(list kalahaye for_sale)bashad:neshan midahad chand nafar ke in model kala ra kharidand
					be un emtiyaz dade and/ agar kala dar head_goods_buyer(list kalhaye sold) bashad:neshan midahad owner chand bar be un
					kalayi ke kharide emtiaz dade(0 ya 1 bar)*/
	struct goods* next;
	char* goods_owner;/*agar kala dar head_goods_buyer->owner=buyer
					  agar kala dar head_goods_seller->owner=seller*/
};
