struct seller {
	char*user_seller_name;
	char*user_seller_password;
	char*user_seller_role;
	int user_seller_accountmoney;
	struct seller* next;
};
