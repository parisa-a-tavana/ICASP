#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h"
void fview_buyer(struct buyer* current_buyer_user, struct goods* head_goods_buyer)

{
	printf("username: %s \n", current_buyer_user->user_buyer_name);
	printf("role: %s \n", current_buyer_user->user_buyer_role);
	printf("account balance: %d \n", current_buyer_user->user_buyer_accountmoney);
	struct goods* temp;
	temp = head_goods_buyer->next;
	while (temp != NULL)
	{
		if (strcmp((temp->goods_owner), (current_buyer_user->user_buyer_name)) == 0)/*agar name saheb kala ba user yeki bood*/
		{
			printf("name of product:%s \t price:%d \t number of products:%d \t seller name: %s \n", temp->goods_name, temp->goods_price, temp->goods_count, temp->goods_seller);
		}
		temp = temp->next;
	}
}