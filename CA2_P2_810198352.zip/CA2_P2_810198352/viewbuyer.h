void fview_buyer(struct buyer* current_buyer_user, struct goods* head_goods_buyer);
/*node buyer login karde va struct ha ra migirad va information user ra print */
