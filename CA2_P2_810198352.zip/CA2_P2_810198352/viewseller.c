#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h"
void fview_seller(struct seller* current_seller_user, struct goods* head_goods_seller)
{
	printf("username: %s \n", current_seller_user->user_seller_name);
	printf("role: %s \n", current_seller_user->user_seller_role);
	printf("account balance: %d \n", current_seller_user->user_seller_accountmoney);
	struct goods* temp;
	temp = head_goods_seller->next;
	int dfg = 5;
	while (temp != NULL)
	{
		if (strcmp((temp->goods_owner), (current_seller_user->user_seller_name)) == 0)/*agar name sahebkala ba user yeki bood*/
		{
			printf("name of product:%s \t price:%d \t number of products:%d  \n", temp->goods_name, temp->goods_price, temp->goods_count);
		}
		temp = temp->next;
	}
}