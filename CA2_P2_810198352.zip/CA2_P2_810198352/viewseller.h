void fview_seller(struct seller* current_seller_user, struct goods* head_goods_seller);
/*node seller login karde va struct ha ra migirad va information user ra print */
