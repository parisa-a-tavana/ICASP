#include <stdlib.h>
#include <stdio.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h"
void fwrite_file_goods(FILE* goods, struct goods* head_goods_seller, struct goods* head_goods_buyer)
{
	struct goods* current_write_goods;
	current_write_goods = head_goods_seller->next;
	while (current_write_goods != NULL)
	{
		fprintf(goods, "for_sale");
		fprintf(goods, " ");
		fprintf(goods, "%s", current_write_goods->goods_owner);
		fprintf(goods, " ");
		fprintf(goods, "%s", current_write_goods->goods_name);
		fprintf(goods, " ");
		fprintf(goods, "%s", current_write_goods->goods_seller);
		fprintf(goods, " ");
		fprintf(goods, "%d", current_write_goods->goods_price);
		fprintf(goods, " ");
		fprintf(goods, "%d", current_write_goods->goods_count);
		fprintf(goods, " ");
		fprintf(goods, "%d", current_write_goods->sum_rate);
		fprintf(goods, " ");
		fprintf(goods, "%d", current_write_goods->count_rater);
		fprintf(goods, "\n");
		current_write_goods = current_write_goods->next;
	}
	current_write_goods = head_goods_buyer->next;
	while (current_write_goods != NULL)
	{
		fprintf(goods, "sold");
		fprintf(goods, " ");
		fprintf(goods, "%s", current_write_goods->goods_owner);
		fprintf(goods, " ");
		fprintf(goods, "%s", current_write_goods->goods_name);
		fprintf(goods, " ");
		fprintf(goods, "%s", current_write_goods->goods_seller);
		fprintf(goods, " ");
		fprintf(goods, "%d", current_write_goods->goods_price);
		fprintf(goods, " ");
		fprintf(goods, "%d", current_write_goods->goods_count);
		fprintf(goods, " ");
		fprintf(goods, "%d", current_write_goods->sum_rate);
		fprintf(goods, " ");
		fprintf(goods, "%d", current_write_goods->count_rater);
		fprintf(goods, "\n");
		current_write_goods = current_write_goods->next;
	}
}