#include <stdlib.h>
#include <stdio.h> 
void fwrite_file_goods(FILE* goods, struct goods* head_goods_seller, struct goods* head_goods_buyer);