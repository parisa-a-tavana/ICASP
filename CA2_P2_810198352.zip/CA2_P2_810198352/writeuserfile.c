#include <stdlib.h>
#include <stdio.h> 
#include <string.h>
#include"structbuy.h"
#include"structgood.h"
#include"structseller.h"
void fwrite_file_user(FILE* user, struct seller* head_seller, struct buyer* head_buyer)
{
	struct seller* current_write_user_seller;
	struct buyer* current_write_user_buyer;
	current_write_user_seller = head_seller->next;
	while (current_write_user_seller != NULL)
	{
		fprintf(user, "%s", current_write_user_seller->user_seller_role);
		fprintf(user, " ");
		fprintf(user, "%s", current_write_user_seller->user_seller_name);
		fprintf(user, " ");
		fprintf(user, "%s", current_write_user_seller->user_seller_password);
		fprintf(user, " ");
		fprintf(user, "%d", current_write_user_seller->user_seller_accountmoney);
		fprintf(user, "\n");
		current_write_user_seller = current_write_user_seller->next;
	}
	current_write_user_buyer = head_buyer->next;
	while (current_write_user_buyer != NULL)
	{
		fprintf(user, "%s", current_write_user_buyer->user_buyer_role);
		fprintf(user, " ");
		fprintf(user, "%s", current_write_user_buyer->user_buyer_name);
		fprintf(user, " ");
		fprintf(user, "%s", current_write_user_buyer->user_buyer_password);
		fprintf(user, " ");
		fprintf(user, "%d", current_write_user_buyer->user_buyer_accountmoney);
		fprintf(user, "\n");
		current_write_user_buyer = current_write_user_buyer->next;
	}
}