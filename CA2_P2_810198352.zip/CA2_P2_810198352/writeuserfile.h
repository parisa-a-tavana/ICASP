#include <stdlib.h>
#include <stdio.h> 
void fwrite_file_user(FILE* user, struct seller* head_seller, struct buyer* head_buyer);